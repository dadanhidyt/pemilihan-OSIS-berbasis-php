<?php
//koneksikan ke daabase
include("../koneksi.php");
if(isset($_GET['data'])){
  echo "<label for='kelas'>Pilih kelas</label><select id='kelas' class='form-control' name=\"kelas\">";
  echo "<option value=\"all\">All</option>";
  if($_GET['data'] == "data_kelas"){
    //cokot kelas ti tabel siswa
    if($getKelas = $konek->query("SELECT kelas_siswa as kelas from tb_siswa")){
      //hasilna ngaran kelas
     while($row = $getKelas->fetch_assoc() ){
        echo "<option value='".$row['kelas']."'>".$row['kelas']."</option>";
     }
    echo "</select>";
    }
  }
}else{
  die("Akses dilarang");
}

?>