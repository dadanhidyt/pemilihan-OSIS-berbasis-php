<?php
//manggil file koneksi
include ('../koneksi.php');
//manggil file comon function
include ( '../code/pko.function.php' );
include ( '../code/autentikasi.php' );

/**
*Cek hela host nu request permintaan ti host website ie soarangan atawa ti luar
*mun ti luar tolak permuntaan demi keamanan
**/
if(isset($_SERVER['HTTP_ORIGIN'])){
  if(strpos(isset($_SERVER['HTTPS'])  && $_SERVER['HTTPS']=='on'? 'https://':'http://'.$_SERVER['SERVER_NAME'],$_SERVER['HTTP_ORIGIN']) !== 0){
    exit("Server menolak permintaan dari ".$_SERVER['HTTP_ORIGIN']);
  }
}else{
  exit("Permintaan di tolak!!!");
}
//memulai session
session_start();
if(function_exists('apache_request_headers')){
  $r = apache_request_headers();
  $csrf = $r['X-CSRF-Token'];
}else{
  $csrf = $_POST['csrf'];
}
//cek token csrf na sarua atawa hente 
//mun sarua valid mun te sarua teu valid
if( $_SESSION['csrf'] == $csrf){
  //cek hela nu milih ges login atawa acan
  if(GesLogin()){
    //cokot id nu ges login
    $id = $_SESSION['id'];
    //cek hela nu login na siswa atawa guru
    if(NuLogin() == "siswa"){
      $siswa = $konek->query("SELECT nis_siswa FROM tb_siswa WHERE id_siswa='$id'");
      $f = $siswa->fetch_assoc();
      $kode = $f['nis_siswa'];
      $link = 'index';

    }elseif(NuLogin() == 'guru'){
      $guru = $konek->query("SELECT kode_guru FROM tb_guru WHERE id_guru='$id'");
      $f = $guru->fetch_assoc();
      $kode = $f['kode_guru'];
      $link = "guru";
    }
    $pilihan = $_POST['pilihan'];  
    if($konek->query("INSERT INTO tb_suara VALUES('$kode','$pilihan') ")){
     if(NuLogin() == "siswa"){
      $konek->query("UPDATE tb_siswa SET sudah_memilih='Y' WHERE id_siswa='$id'");
     }elseif(NuLogin() == "guru"){
      $konek->query("UPDATE tb_guru SET sudah_memilih='Y' WHERE id_guru='$id'");
     }
     //print json
      echo json_encode(
        array(
          'error'=>0,
          'status'=>'success',
          'message'=>'Sukses, Terimakasih atas partisipasinya',
          'to_link'=>$link
        )
      );
    }else{
      //print json
      echo json_encode(
        array(
          'error'=>1,
          'status'=>'gagal',
          'message'=>'Gagal, Sepertinya ada kesalahan saat memperoses permintaaan'
        )
      );
    }
  }

}
?>