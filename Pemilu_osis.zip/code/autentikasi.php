<?php
/**
 * @author dadan hiayat
 * DI JIEN TANGGAL 14 DESEMBER 2021
 */

//fungsi jangen apal nu login na guru atawa siswa
function NuLogin(){
  if(isset($_SESSION['geslogin']) && $_SESSION['geslogin'] == true) {
    $nulogin = $_SESSION['nulogin'];
    return $nulogin;
  }else{
    return false;
  }
}
//jangen ngecek ges login ataw acan
//mun login true mun acan false
function GesLogin(){
  if(isset($_SESSION['geslogin']) && $_SESSION['geslogin'] == true) {
    return true;
  }else{
    return false;
  }
}
