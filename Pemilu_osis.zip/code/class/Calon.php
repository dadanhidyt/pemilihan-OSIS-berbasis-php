<?php
//kelas jangen nyokot calon
/**
 * @author dadan hiayat
 * DI JIEN TANGGAL 14 DESEMBER 2021
 */
class Calon{
  public $db;
  function __construct($db){
    $this->db = $db;
  }
  //nyokot calon osis
  function CalonAll(){
    if($ac = $this->db->query("SELECT * FROM tb_calon")){
      if($ac->num_rows > 0){
        while($row = $ac->fetch_assoc()){
          $data [] = $row;
        }
        return $data;
      }
      $this->db->close();
    }
  }
}