<?php
/**
 * Login siswa
 * Jeng login guru
 * @author dadan hiayat
 * DI JIEN TANGGAL 15 DESEMBER 2021
 */
class Login{
  //variabel jangen nampung koneksi
  public $db;
  public $errormsg;
  //kosntruktor
  function __construct($db){
    $this->db = $db;
  }
  //jangen ngecek variabel kosong atau hente
  function TeuKosong($string){
    if(empty($string)){
      return false;
    }else{
      return true;
    }
  }
  //fungsi jangen login siswa
  function LoginSiswa($nis,$pass){
    if(!$this->TeuKosong($nis) && !$this->TeuKosong($pass)){
      $this->errormsg = "Nisn Sareng Password teu kenging kosong";
    }elseif(!$this->TeuKosong($nis)){
      $this->errormsg = "Nisn teu kenging kosong";
    }elseif(!$this->TeuKosong($pass)){
      $this->errormsg = "Password teu kenging kosong";
    }else{
      //validasi hela supaya akun na teu ka injeksi
      $nis = strip_tags($this->db->escape_string($nis));
      $pass = strip_tags($this->db->escape_string($pass));
      //cek nis sareng password na
      if($c = $this->db->query("SELECT * FROM tb_siswa where nis_siswa='$nis' AND password='$pass'")){
        if($c->num_rows==1){
          return $c->fetch_object();
        }else{
          $this->errormsg = "Nis sareng password na salah";
          return false;
        }
      }

    }
  }
  //fungsi jangen login guru
  function LoginGuru($nama,$pass){
    if(!$this->TeuKosong($nama) && !$this->TeuKosong($pass)){
      $this->errormsg = "Nama Sareng Password teu kenging kosong";
    }elseif(!$this->TeuKosong($nama)){
      $this->errormsg = "Nama teu kenging kosong";
    }elseif(!$this->TeuKosong($pass)){
      $this->errormsg = "Password teu kenging kosong";
    }else{
      //validasi hela supaya akun na teu ka injeksi
      $nama = strip_tags($this->db->escape_string($nama));
      $pass = strip_tags($this->db->escape_string($pass));
      //cek nis sareng password na
      if($c = $this->db->query("SELECT * FROM tb_guru where nama='$nama' AND password='$pass'")){
        //lamun akun nu di ketien aya di database
        //login berhasil return data nu login
        if($c->num_rows== 1){
          return $c->fetch_object();
        }else{
          $this->errormsg = "Nama sareng password na salah";
          return false;
        }
      }

    }
    }
}
?>
