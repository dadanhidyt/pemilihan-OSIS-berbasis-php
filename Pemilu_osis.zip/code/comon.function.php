<?php
/**
 * Ngaran file common.function.php
 * @author dadan hiayat
 * DI JIEN TANGGAL 14 DESEMBER 2021
 */
//fungsi jangen ngubah ka format tanggal di indonesia
date_default_timezone_set("Asia/Jakarta");
function TanggalIndonesia ( $tanggal ) {
  $bulanIndonesia = array(1=>"Januari",
    "Februari",
    "Maret",
    "Aprl",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember"
  );
  $hariIndonesia = array(1=>"Senin",
    "Selasa",
    "Rabu",
    "Kamis",
    "Jum'at",
    "Sabtu",
    "Minggu"   
  );
  //pecah tanggal jadi array 
  /**
   * 0 = 2021
   * 1 = 4
   * 2 = 1
   * 
   */
  $split = explode('-', $tanggal );
  //menambahkan hari
  $hari = date("N",strtotime($tanggal));
  $h = $hariIndonesia[(int)$hari];
  //susun ulang
  $y = $split[0];
  $m = $bulanIndonesia[1*$split[1]];
  $d = $split[2];


  return $h.", ".$d." ".$m." ".$y;

}

//jangen nyien token csrf
function generateCsrf(){
  //string acak jangen csrf
  $csrf = sha1(uniqid());
  return $_SESSION['csrf'] = $csrf;
}
