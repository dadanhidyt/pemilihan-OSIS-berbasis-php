<?php

/**
 * Fungsi cek waktu pemilihan
 * @author dadan hiayat
 * DI JIEN TANGGAL 14 DESEMBER 2021
 * @return boolean tre|false
 */
//jangen ngecek ayna hari pemilihan atawa lain
function BedaJadwal(){
  global $konek;
  if( $a = $konek->query("SELECT dari FROM tb_jadwal") ) {
    $a =$a->fetch_assoc();
    $waktuAyena = intval(strtotime(date("Y-m-d")));
    $mulai = intval(strtotime($a['dari']));
    $waktu = (($mulai-$waktuAyena)/86400);
    if( $waktu > 0 ) {
      return floor($waktu);
    }else{
      return false;
    }
  }else{
    echo $konek->error;
  }
  //Ngadefinisiken waktu ayena
  
}
/**
 * @return boolean true|false
 */
//jangen ngecek hari pemilihan gen beres atawa acan
function JadwalSelesai(){
  global $konek;
  if( $a = $konek->query("SELECT sampai FROM tb_jadwal") ) {
    $a =$a->fetch_assoc();
    $waktuAyena = intval(strtotime(date("Y-m-d")));
    $mulai = intval(strtotime($a['sampai']));
    $waktu = (($mulai-$waktuAyena)/86400);
    if( $waktu < 0 ) {
      return floor($waktu);
    }else{
      return false;
    }
  }else{
    echo $konek->error;
  }
  //Ngadefinisiken waktu ayena
}

//cek hari sesi
//poe ayna bagean sesi nu login atawa lain
function CekHari($sesiname){
  global $konek;
  date_default_timezone_set("asia/jakarta");
  $hariSekarang = date("N");
  $hari = array(1=>'Senin',
                   'Selasa',
                   'Rabu',
                   'Kamis',
                   'Jumat',
                   'Sabtu',
                   'Minggu'
);
$ghari = $konek->query("SELECT hari from tb_sesi WHERE nama_sesi='$sesiname'");
$gh = $ghari->fetch_assoc();
$ha = ucfirst($hari[$hariSekarang]);
$harisesi = ucfirst($gh['hari']);
if( $ha == $harisesi ) {
  return true;
}else{
  return false;
}
}
/*
Jangen ngecek sesi nu login
Waktuna pemilihan atawa lain
*/
function CekSessi($namasesi){
  //nyokot user
  global $konek;
  //nyokot sessi ti database
  $sesi = $konek->query("SELECT * FROM tb_sesi WHERE nama_sesi='$namasesi'");
  $ws = $sesi->fetch_object();
  $waktuayena = strtotime(date("H:i:s"));
  //nyokot waktu sesi mulai
  $ws1 = strtotime($ws->mulai);
  //nyokot waktu sesi akhir
  $ws2 = strtotime($ws->akhir);
  $kurangawal = $ws1-$waktuayena;
  //cek sesi awal
  $jamawal = floor($kurangawal/3600);
  $menitawal = floor($kurangawal/60);
  //cek sesi akhir
  $kurangakhir = $ws2-$waktuayena;
  $jamakhir = floor($kurangakhir/3600);
  $menitakhir = floor($kurangakhir/60);
  if($jamawal > 0){
    header("location:msg-alert?msg=beda-sesi");
  }elseif($menitawal > 0){
      header("location:msg-alert?msg=beda-sesi");
  }elseif($jamakhir < 0){
    header("location:msg-alert?msg=sesi-kalewat");
  }elseif($menitakhir < 0){
    header("location:msg-alert?msg=sesi-kalewat");
  }

}

//fungsi jangen ngecek ges milih atawa acan
function GesMilih($uid){
  global $konek;
  if(NuLogin() == "siswa"){
    $wk = $konek->query("SELECT * FROM tb_siswa INNER JOIN tb_suara ON tb_suara.pemilih=tb_siswa.nis_siswa WHERE id_siswa='$uid'");

  }elseif(NuLogin()=="guru"){
    $wk = $konek->query("SELECT * FROM tb_guru INNER JOIN tb_suara ON tb_suara.pemilih=tb_guru.kode_guru WHERE id_guru='$uid'");

  }
  if($wk->num_rows == 1){
    return true;
  }else{
    return false;
  }
}