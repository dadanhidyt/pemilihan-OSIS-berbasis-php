-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2021 at 09:49 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pemilihan-osis`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `foto_admin` varchar(223) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `email`, `password`, `foto_admin`) VALUES
(1, 'admin@admin.com', '200ceb26807d6bf99fd6f4f0d1ca54d4', '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_calon`
--

CREATE TABLE `tb_calon` (
  `id` int(11) NOT NULL,
  `no_calon` int(11) NOT NULL,
  `Nama_calon` varchar(52) NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar_calon` text NOT NULL,
  `jumlah_suara` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_calon`
--

INSERT INTO `tb_calon` (`id`, `no_calon`, `Nama_calon`, `deskripsi`, `gambar_calon`, `jumlah_suara`) VALUES
(37, 1, 'Aril Noah', '<p><strong>VISI</strong></p>\r\n<p>Membangun masyarakat sekolah dan menjadikan sekolah bukan hanya untuk belajar tapi untuk berniaga dan mendapatkan chuan</p>\r\n<p><strong>MISI</strong></p>\r\n<ol>\r\n<li>lorem</li>\r\n<li>ipsum dolor</li>\r\n<li>sit amet conste</li>\r\n<li>how do you do</li>\r\n</ol>\r\n<p>&nbsp;</p>', 'fotocalon-61c436e264aa8.jpg', 0),
(38, 2, 'Shandy Chan', '<p><strong>VISI</strong></p>\r\n<p>Membangun masyarakat sekolah dan menjadikan sekolah bukan hanya untuk belajar tapi untuk berniaga dan mendapatkan chuan wkkw whada dada dada</p>\r\n<p>&nbsp;</p>\r\n<p><strong>MISI</strong></p>\r\n<ol>\r\n<li>lorem</li>\r\n<li>ipsum dolor</li>\r\n<li>sit amet conste</li>\r\n<li>how do you do</li>\r\n</ol>', 'fotocalon-61c4374390e01.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_guru`
--

CREATE TABLE `tb_guru` (
  `id_guru` int(11) NOT NULL,
  `kode_guru` varchar(18) DEFAULT NULL,
  `nama` varchar(25) NOT NULL,
  `password` varchar(16) NOT NULL,
  `sesi` int(11) NOT NULL,
  `sudah_memilih` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_guru`
--

INSERT INTO `tb_guru` (`id_guru`, `kode_guru`, `nama`, `password`, `sesi`, `sudah_memilih`) VALUES
(128, 'GURU-EBFC3', 'Dadan Hidayat J,PG', 'FjJtV2', 30, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jadwal`
--

CREATE TABLE `tb_jadwal` (
  `dari` date NOT NULL,
  `sampai` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_jadwal`
--

INSERT INTO `tb_jadwal` (`dari`, `sampai`) VALUES
('2021-12-24', '2021-12-26');

-- --------------------------------------------------------

--
-- Table structure for table `tb_sesi`
--

CREATE TABLE `tb_sesi` (
  `id_sesi` int(11) NOT NULL,
  `nama_sesi` int(11) NOT NULL,
  `mulai` time NOT NULL DEFAULT current_timestamp(),
  `akhir` time NOT NULL DEFAULT current_timestamp(),
  `hari` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `id_siswa` int(11) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `nis_siswa` bigint(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `kelas_siswa` varchar(40) NOT NULL,
  `sesi` int(11) NOT NULL,
  `sudah_memilih` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`id_siswa`, `nama_siswa`, `nis_siswa`, `password`, `kelas_siswa`, `sesi`, `sudah_memilih`) VALUES
(12548, 'Dadan Hidayat', 20211324, 'GCMTn4', 'XI-RPL-10', 1, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tb_suara`
--

CREATE TABLE `tb_suara` (
  `pemilih` varchar(11) NOT NULL,
  `ke_calon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tb_calon`
--
ALTER TABLE `tb_calon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_calon` (`no_calon`);

--
-- Indexes for table `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD PRIMARY KEY (`id_guru`),
  ADD UNIQUE KEY `kode_guru` (`kode_guru`);

--
-- Indexes for table `tb_sesi`
--
ALTER TABLE `tb_sesi`
  ADD PRIMARY KEY (`id_sesi`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `tb_suara`
--
ALTER TABLE `tb_suara`
  ADD UNIQUE KEY `pemilih` (`pemilih`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_calon`
--
ALTER TABLE `tb_calon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tb_guru`
--
ALTER TABLE `tb_guru`
  MODIFY `id_guru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `tb_sesi`
--
ALTER TABLE `tb_sesi`
  MODIFY `id_sesi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12549;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
