<?php
session_start();
/**
 * Ngaran File: guru.php
 * @author dadan hiayat
 * DI JIEN TANGGAL 14 DESEMBER 2021
 */
//nge set zonawaktu
date_default_timezone_set("Asia/Jakarta");
//manggil file koneksi ka database
require( 'koneksi.php' );
//manggil file fungsi-fungsi
require( 'code/comon.function.php' );
require( 'code/pko.function.php' );
/**
 * Ngecek waktu pemilihan
 * Lamun waktu pemilihan lain sesuai jadwal nu ges di tangtuken 
 * User bakal di alihkeun kanu halaman pesan
 */
if( BedaJadwal() != false ) {
    //lamun acan waktuna pindakhen user ka halaman pesan acan waktuna
  header("location:msg-alert?msg=belum-waktunya");
  return;
} elseif( JadwalSelesai() !== false ) {
    //lamun jadwal 
  header( "location:msg-alert?msg=sudah-selesai" );
  return;
}

//manggil file class jangen fungsi jangen login
include( "code/class/Login.php" );
//lamun tombbol login ges di klik
if( isset($_POST['login']) && $_SERVER['REQUEST_METHOD'] == "POST") {
  //nyien instance siswa jangen login siswa
  $siswa = new Login($konek);
  if($ps = $siswa->LoginGuru($_POST['nama_guru'],$_POST['password'])){
    $_SESSION['geslogin'] = true;
    $_SESSION['nulogin'] = "guru";
    $_SESSION['id'] = $ps->id_guru;
    header("location:ruang_pilih");
    exit;
  }else{
    $errormsg = $siswa->errormsg;
  }
} 

$title = "Halaman login Guru";
/**
 * Manggil file pko_html-header nu esina informasi informasi ngenaan website
 * Kos title
 */
include( "pko_html-header.php" );

?>
<!-- HALAMAN LOGIN JANGEUN GURU -->
<div class="container mt-5">
  <div class="col-md-12 pko-login">
    <div class="row">
      <!-- Gambar Halaman sakola -->
      <div class="col-md-6 overflow-hidden">
       <div class="row">
         <div class="gambar-lapang">
           <div class="headings">
             <h2>PEMILIHAN KETUA OSIS SMK INFORMATIKA SUMEDANG 2022/2023</h2>
           </div>
           <img src="images/background.jpg" alt="">
         </div>
       </div>
     </div>
     <!-- jangen form login -->
     <div class="col-md-6">
      <div class="box-pko-login">
        <div class="boxs-title-login">
          <!-- logo sakola -->
          <div class="logo-sekolah">
            <img class="logo" src="images/ifsu.png" alt="">
          </div>
          
        </div>
        <!-- end logo sakla -->
        <!-- form login -->
        <div class="boxs-login col-md-8 offset-md-2 mb-5 mt-3">
          <?php
          if(isset($errormsg)){
            echo "<p class=\"alert alert-info\">$errormsg</p>";
          }
          ?>
          <form action="" method="POST">
            <div class="form-group">
              <label for="nisn">Nama</label>
              <input required autocomplete="off" autofocus type="num" name="nama_guru" placeholder="Masukan Nama" class="form-control">
            </div>
            <div class="form-group">
              <label for="Password">Password</label>
              <input required autocomplete="off" autofocus name="password" type="Password" placeholder="Masukan password" class="form-control">
            </div>
            <div class="form-group mt-4">
              <input type="submit" name="login" class="btn btn-block btn-primary" value="Masuk">
            </div>
          </form>
          <!-- bagian powered -->
          <div class="powered mt-4">
           <h6 class="text-center mb-2">
             Powered By:
           </h6>
           <div class="powered-items">
            <img class="logo" src="images/osis.jpg" alt="">
            <img class="logo" src="images/mpk.jpg" alt="">
            <img class="logo" src="images/logo-icso.png" alt="">
          </div>
        </div>
        <!-- end bagian powered -->
      </div>
    </div>
    <!-- end form login -->
  </div>
</div>
</div>
</div>
<!-- AKHIR HALAMAN LOGIN GURU -->
<body>
</html>
