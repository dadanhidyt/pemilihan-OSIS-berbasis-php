<?php
//file koneksi ke database
$namahost = "localhost";
$namauser = "root";
$password = "";
$namadatabase   = "db_pemilihan-osis";

try{

  $konek = @new mysqli($namahost,$namauser,$password,$namadatabase);
  if( $konek->connect_errno ) {
    throw new Exception("Gagal ngaakses database");
  }
  
}catch( Exception $e ) {
  die($e->getMessage());
}
//untuk menyamakan waktu server dan waktu database