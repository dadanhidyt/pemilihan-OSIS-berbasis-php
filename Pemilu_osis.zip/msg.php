<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Notification</title>
  <link rel="stylesheet" href="assts/style.css">

</head>

<body>
  <?php
  //jika di dalam apli
  //manggil file file nu di butuhken
  include "koneksi.php";
  //fungsi jangen manggil fungsi fungsi nu di butuhken
  include 'code/pko.function.php';
  include 'code/comon.function.php';
  include 'code/autentikasi.php';
  if(isset($_GET['msg'])){
    //unset atau hapus session
    session_start();
    session_unset();
    session_destroy();
    unset($_SESSION['id']);
    switch ($_GET['msg']) {
      //untuk pesan jika pemilihan belum waktunya
      case 'belum-waktunya':
      if(BedaJadwal() == false){
        header('location:index');
        exit;
      }
      ?>
    <h1> Jadwal Pemilihan ketua osis <?= BedaJadwal() ?> Hari lagi </h1>
    <?php
      
      break;
         //pesan jika siswa sudah telat memilih
      case'sudah-selesai':
      if(JadwalSelesai() == false){
        header('location:index');
      }
      echo "ACARA PEMILIHAN KETUA OSIS SMK INFORMATIKA SUMEDANG SUDAH SELESAI!";
      break;
        //untuk pesan jika sudah memilih
      case "sudah-memilih":
      echo"MAAF KAMU SUDAH MEMILIH SEBELUMNYAA!! JIKA ADA YANG MAU DI TANYAKAN HUBUNGI PANITIA 088223831765";
      echo "<script>setTimeout(\"document.location.href='index'\",5000)</script>";
      break;
            //pesan jika beda hari
      case "beda-hari":
      echo "MAAF BEDA HARI!!! SESI KAMU BUKAN HARI INI,,, COBA HUBUNGI PANITIA";
      echo "<script>setTimeout(\"document.location.href='index'\",5000)</script>";

      break;
  //pesan jika selesai memilih
      case"selesai-memilih";
      echo "YEYYYYYY! KAMU SUDAH MELAKUKAN PEMILIHAN,,,TERIMAKASIH SUDAH BERPARTISIVASI";
      echo "<script>setTimeout(\"document.location.href='index'\",5000)</script>";

      break;

      //lamun sesi kalewat
      case"sesi-kalewat";
      echo "SESI GILIRAN KAMU SUDAH KELEWAT!! SILAHKAN MENGIKUTI SUSULAN,,,";
      echo "<script>setTimeout(\"document.location.href='index'\",5000)</script>";

      break;
            //pesan jika beda sesi
      case"beda-sesi";
      echo "BEDA SESI KAMU TIDAK DAPAT MEMILIH DI SESI INI,,, Hubungi panitia untuk informasi lebih lanjut";
      echo "<script>setTimeout(\"document.location.href='index'\",5000)</script>";

      break;
      default:
        # code...
      break;
    }
  }
  ?>
</body>

</html>