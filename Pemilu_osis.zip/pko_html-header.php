<!-- 
  CREATED: Icso dev team
 -->
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Manggil css -->
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <!-- App css -->
  <link rel="stylesheet" href="assets/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=none">
  <title><?php echo isset($title) ? $title : "" ?></title>
</head>
<body>