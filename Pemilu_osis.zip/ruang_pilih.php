<?php
/**
 * @author dadan hidayat
 */

//manggil file koneksi
include("koneksi.php");
//manggil file common function nu esina fungsi-fungsi pembantu
include("code/comon.function.php");
//manggil file pko.function nu esina fungsi fungsi kos cek sesi dll
include("code/pko.function.php");
//manggil file autentikasi nu esina cek session,ngambil session dll
include("code/autentikasi.php");
session_start();
/**
 * Cek hela ges login atawa acan, Lamun can login pindahken ka halaman login
 * Mun ges login siswa/guru bisa milih
 */
if(!GesLogin()){
  //mun acan arahken ka halaman index
  header("location:index");
}
//cokot id nu ges login
$id = $_SESSION['id'];
/**
 * Cek hela siswa/guru nu login ges milih atawa acan
 * Lamun ges milih pindahken ka halaman sudah login
 * Sabab siswa/guru teu bisa milih 2 kali
 */
if(GesMilih($id)){
  //cek hela geus milih atawa acan
  header("location:msg-alert?msg=sudah-memilih");
  exit;
}
/**
 * Cek hela nu login na siswa atawa guru
 * Mun siswa cokot data siswa nu login
 * Lamun guru cokot data guru nu login
 */
if(NuLogin() == "siswa"){
  //cokot data na
  $ambil = $konek->query("SELECT id_siswa,sesi,nama_siswa FROM tb_siswa WHERE id_siswa='$id'");
  //lamun nu login na guru cokkot data guru nu login
}elseif(NuLogin() == "guru"){
  //cokot datana
  $ambil = $konek->query("SELECT * FROM tb_guru WHERE id_guru='$id'");
}else{
  header('location:index');
}
//Fetch data na ka object
$fetch = $ambil->fetch_object();
//nyokot sesi siswa/guru
$sesi = $fetch->sesi;
/**
 * Cek hela sesi na sesi guru atawa lain
 * dengan catatan guru mah teu di sesi milih iraha wae ge bisa
 * Sesi guru nyaeta (30) khusus
 */
if($sesi != 30){
  //cek hela poe na sesi siswa bagean ayna atau lain
  if(CekHari($sesi) == false){
    //lamun lain arahken user ka halaman beda hari
    header("location:msg-alert?msg=beda-hari");
  }else{
    //Cek sesi na
    CekSessi($sesi);
  }
}
//lamun semuana aman bisa milih
$title = "PILIH CALON";
include( "pko_html-header.php" );
//manggil kelas calon
include( "code/class/Calon.php" );
//nyien objek
$Calon = new Calon($konek);

?>
<!-- header -->

<header id="header">

  <div class="container">

    <div class="logo">
      <h4 class="text-center">PEMILIHAN KETUA OSIS SMK SUKA JAJAN</h4>
    </div>

  </div>

</header>

<!-- /end header -->

<!-- box-calon -->
<div class="col-md-12">
  <div class="container mt-4">
    <!-- info -->
    <p style="border-radius: none;" class="alert alert-info">Klik salah satu foto calon! Lalu scroll ke bawah dan klik Tombol PILIH</p>
    <!-- FORM PILIHAN -->
    <form action="" onsubmit="Pilih(event)" method="post">
      <input type="hidden" name="csrf" value="<?= generateCsrf() ?>">
      <div class="row">   
        <?php
        //mendapatkan data calon
        if(count($Calon->CalonAll()) > 0){
          foreach($Calon->CalonAll() as $datacalon){
            ?>
            <!-- CARD_CALON -->
            <div class="col-md-3">
             <label for="BOX_PIL<?=  $datacalon['no_calon'] ?>">
              <input type="radio" hidden class="item-calon" name="pilihan" value="<?= $datacalon['no_calon'] ?>" id="BOX_PIL<?=  $datacalon['no_calon'] ?>">
              <div class="card-calon card">
               <div class="nc">
                 <div class="no-calon">

                  <?= $datacalon['no_calon'] ?>

                </div>
              </div>
              <div class="gambar-calon">
                <img src="images/foto-calon/<?= $datacalon['gambar_calon'] ?>" alt="">
              </div>
              <div class="card-body">
                <div class="text-center">
                  <b>  <?= strtoupper($datacalon['Nama_calon']) ?></b>
                </div>
                <div class="mt-3 ">
                  <details>
                    <summary >DETAIL</summary>
                    <?php echo htmlspecialchars_decode($datacalon['deskripsi']) ?>
                  </details>    
                </div>
              </div>
            </div>

          </label>
        </div>
        <!-- END CARD_CALON -->
        <!-- MODAL JANGEN DETAIL KANDIDAT -->
        <?php
      }
    }
    ?>
  </div>
  <div class="mt-4 btnsku mb-5">

  </div>
</form>
<!-- ../FORM PILIHAN -->
</div>
</div>
<script>
  //script kanggo memproses pemilihan
  var _radio = document.querySelectorAll(".item-calon");
  var _btn = document.querySelector(".btnsku");
  const btn = document.createElement("BUTTON");
  btn.name = "pilih";
  btn.className = "btn btns-vote btn-lg btn-primary";
  _radio.forEach(function(e){
    e.onclick = function(){
      btn.innerText = `PILIH [${e.value}]`;
      _btn.appendChild(btn)
    }
  })
  //fungsi untuk memperoses pilihan
  function Pilih(e){
    e.preventDefault();
    $formdata = new FormData(e.target);
    if(confirm("Apakah anda yakin dengan pilihan ini?")){
      //proses mengunakan ajax
      var ajax = new XMLHttpRequest();
      ajax.open("POST","api/pilih.php");
      ajax.responseType = "json";
      ajax.setRequestHeader("X-CSRF-Token",e.target.csrf.value)
      ajax.send($formdata);
      ajax.onload = function(e){
        const res = e.target.response;
        if(res.error == 0 && res.status == 'success'){
          alert("Terimakasih atas partisipasinya");
          window.location.href='msg-alert?msg=selesai-memilih';
        }else if(res.error == 1 && res.status == 'gagal'){
          alert(res.message);
        }
      }
    }
  }
</script>

</body>
</html>