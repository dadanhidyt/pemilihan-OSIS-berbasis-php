
    Morris.Donut({
        element: 'morris-donut-chart',
        data: [
        {
            label: 'dada',
            value: 1982
        },
        {
            label: 'e.dadan.nama',
            value: 1982
        }
        ],
        resize: true
    });

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: 'Dadan hidayat',
            a: 320,
        }, {
            y: 'Sumarni',
            a: 769,
        }, {
            y: 'Dela puspita',
            a: 34,
        }],
        xkey: 'y',
        ykeys: ['a'],
        labels: ['Total Suara'],
        hideHover: 'auto',
        resize: true
    });

