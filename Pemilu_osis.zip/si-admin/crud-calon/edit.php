<?php 

//cek hela id guru aya atawa eweh
if(isset($_GET['id_calon']) && !empty($_GET['id_calon'])){
	$id = strip_tags($_GET['id_calon']);
	$calon = $konek->query("select * from tb_calon WHERE id='$id'")->fetch_assoc();
	//update data
	if( isset($_POST['edit_calon']) ) {
		$nama_calon = $konek->real_escape_string(htmlspecialchars($_POST['nama_calon']));
		$deskripsi = $konek->real_escape_string(htmlspecialchars($_POST['deskripsi']));
		$filetmp = $_FILES['gambar-calon']['tmp_name'];
		$name = $_FILES['gambar-calon']['name'];
		$extension = pathinfo($name,PATHINFO_EXTENSION);
		if($name == ""){
			$gambar = $calon['gambar_calon'];
		}else{
			$gambar = "foto-calon-".uniqid().".".$extension;
		}	
		if($deskripsi == ""){
			$deskripsi = $calon['deskripsi'];
		}
		if($konek->query("UPDATE tb_calon set Nama_calon='$nama_calon',deskripsi='$deskripsi',gambar_calon='$gambar' WHERE id='$id'")){
			if($name!=""){
				move_uploaded_file($filetmp, "../images/foto-calon/".$gambar);
			}
			echo '<script>alert("update data berhasil");window.location.href="?module=calon"</script>';
		}

	}
//mengambil data guru nu rek di edit
	if($gk = $konek->query("SELECT * FROM tb_calon WHERE id='$id'")){
		if($gk->num_rows ==1){
			$row = $gk->fetch_assoc();
			?>
			<div class="row">
				<div class="col-md-12">
					<div class="page-header">
						<h4>Edit calon</h4>
					</div>
				</div>
			</div>
			<!-- halaman edit calon -->
			<a href="?module=calon"  class="btn btn-warning">Kembali</a><br><br>
			<div class="row">
				<div class="col-md-5">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5>Detail</h5>
						</div>
						<div class="panel-body">
							<table class="table table-user-information">
								<tr>
									<td><b>NO:</b></td>
									<td><?php echo $row['no_calon'] ?></td>
								</tr>
								<tr>
									<td><b>Nama:</b></td>
									<td><?php echo $row['Nama_calon'] ?></td>
								</tr>
								<tr>
									<td><b>deskripsi:</b></td>
									<td style="word-break: break-all"><?php echo htmlspecialchars_decode( $row['deskripsi']) ?></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-7">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5>EDIT CALON</h5>
						</div>
						<div class="panel-body">
							<form action="" method="POST" enctype="multipart/form-data">
								<div class="form-group">
									<label for="nama">Nama</label>
									<input type="text" name="nama_calon" placeholder="Ketikan nama" value="<?php echo $row['Nama_calon'] ?>" class="form-control">
								</div>
								<div class="form-group">
									<label for="deskripsi">deskripsi</label>
									<textarea name="deskripsi" value="<?php echo $row['deskripsi'] ?>" id="edit" class="form-control"></textarea>

								</div>
								<div class="form-group">
									<label for="gambar">Gambar</label>
									<input type="file" name="gambar-calon">
								</div>
								<div class="form-group">
									<button onclick="return confirm('Apakah anda yakin ingin mengubah? ')" type="submit" name="edit_calon" class="btn btn-block btn-success">Simpan perubahan</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>

			<?php

		}else{
			echo '<script>alert("Opps data tersebut sudah tidak ada");document.location.href="?module=calon"</script>';
		}
	}
}else{
	echo '<script>alert("Ada kesalahan");document.location.href="?module=calon"</script>';
}

?>
