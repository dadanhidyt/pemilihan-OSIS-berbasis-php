<?php 
/*
*@author dadan hidayat
*/
defined("calonpage") or die("FOrbidden");
$err = "";
//lamun tombol tambah di tekan
if(isset($_POST['tambah'])){
	//cek hela dina inputan na aya nu kosong teu
	if(empty($_POST['nama_calon'])){
		$err = "Nama calon tidak boleh kosong";
	}elseif(empty($_POST['deskripsi'])){
		$err = "Deskripsi calon tidak boleh kosong";
	}else{
		//cokot file nu di kirim
		$file = $_FILES['foto_calon'];
		//ektensi nu di perbolehkan
		$ext = ['png','jpg','jpeg'];
		//cokot extensi file nu di upload
		//terus huruf na jadi huruf letik bisi aya nu hurufna kapital etage
		$fileext = strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
		//cek hela extensi na di ijinken teu/boleh teu
		//mn boleh lanjut eksekusi kode
		if(in_array($fileext,$ext)){
			//nyien nama file acak supaya te bentrok jeng ngaran file lain
			$namafile = "fotocalon-".uniqid().'.'.$fileext;
			//pindahken file nnu asalna aya di penyimpanan sementara php ke folder images/foto-calon
			if(move_uploaded_file($file['tmp_name'], '../images/foto-calon/'.$namafile)){
				//cokot hela no_calon tertinggi di tabel calon
				$nocalon = $konek->query("SELECT max(no_calon) as terbesar FROM tb_calon")->fetch_object()->terbesar;
				//mn aya di tambah 1
				//misal di db 0 di tambah 1 jadi 1
				$nocalon++;
				//nama calon nu di inputken
				$nama_calon = htmlentities(htmlspecialchars($_POST['nama_calon']));
				//deskripsina,,, nu di jerona aya visi jeng misi
				$deskripsi = 	$_POST['deskripsi'];
				//proses eksekusi
				if($konek->query("INSERT INTO tb_calon (no_calon,Nama_calon,deskripsi,gambar_calon) VALUES('$nocalon','$nama_calon','$deskripsi','$namafile')")){
					//lamun data berhasil di tambahken tampilken pesan di handap iyeu
					echo '<script>alert("Data berhasil di tambahkan");window.location.href="?module=calon"</script>';
				}else{
					//mun gagal tampilken iyeu
					echo '<script>alert("Ada kesalahan saat menambahkan data");window.location.href="?module=calon"</script>';

				}				
			}
		}
	}
}


?>
<!-- halaman tambah data -->
<div class="row">
	<div class="col-md-12">
		<div class="page-header">
			<h4>Tambah data calon</h4>
		</div>
	</div>
</div>
<!-- page tambah calon -->
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<b>Tambah data calon</b>
			</div>
			<div class="panel-body">
				<?= $err !== "" ? "<p class='alert alert-danger'>".$err."</p>" : '' ?>

				<form action="" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label for="">Nama calon</label>
						<input type="text" name="nama_calon" required placeholder="ketikan nama calon" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Foto calon</label>
						<input type="file" name="foto_calon" required placeholder="ketikan nama calon" class="form-control">
					</div>
					<!-- menggunakan wysiwyg -->
					<div class="form-group">
						<label for="">DESKRIPSI</label>
						<textarea  name="deskripsi" id="deskripsicalon"></textarea>
					</div>
					<!-- ..end -->
					<div class="form-group">
						<button name="tambah" type="submit" class="btn btn-success">Kirim</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>