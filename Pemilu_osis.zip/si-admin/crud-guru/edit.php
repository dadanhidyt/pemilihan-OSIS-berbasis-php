

<div class="row">
  <div class="col-lg-12">
      <div class="page-header"><h3>Edit data Guru</h3></div>
  </div>
  <!-- /.col-lg-12 -->
</div>
<a href="?module=guru"  class="btn btn-warning">Kembali</a>
	<br>
	<br>
	<?php 

//cek hela id guru aya atawa eweh
if(isset($_GET['id_guru']) && !empty($_GET['id_guru'])){
	$id = strip_tags($_GET['id_guru']);
	//update data
if( isset($_POST['edit']) ) {
	$nama = $konek->real_escape_string(htmlspecialchars($_POST['nama_guru']));
	$password = $konek->real_escape_string(htmlspecialchars($_POST['password']));
	$sesi = $konek->real_escape_string(htmlspecialchars($_POST['sesi']));
	
	if( $konek->query("UPDATE tb_guru SET nama='$nama',password='$password',sesi='$sesi' WHERE id_guru='$id'" ) ){
		echo "<script>alert('Update data berhasil')</script>";
	}else{
		echo $konek->error;
	}
}
//mengambil data guru nu rek di edit
	if($gk = $konek->query("SELECT * FROM tb_guru WHERE id_guru='$id'")){
		if($gk->num_rows ==1){
			$row = $gk->fetch_assoc();
			?>

			<div class="row">
		<div class="col-md-5">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h5>Detail</h5>
				</div>
				<div class="panel-body">
					<table class="table table-user-information">
						<tr>
							<td><b>Nama:</b></td>
							<td><?php echo $row['nama'] ?></td>
						</tr>
						<tr>
							<td><b>Kode_guru:</b></td>
							<td><?php echo $row['kode_guru'] ?></td>
						</tr>
						<tr>
							<td><b>Password:</b></td>
							<td><?php echo $row['password'] ?></td>
						</tr>
						<tr>
							<td><b>Sesi:</b></td>
							<td><?php echo $row['sesi'] ?></td>
						</tr>
						<tr>
							<td><b>Sudah memilih:</b></td>
							<td><?php echo $row['sudah_memilih'] == "Y" ? "<font color='green'>Sudah</font>" : "<font color='red'>Belum</font>"  ?></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
		<div class="col-md-7">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h5>EDIT SISWA</h5>
				</div>
				<div class="panel-body">
					<form action="" method="POST">
						<table class="table">
							<tr>
								<td><b>Nama:</b></td>
								<td><input type="text" name="nama_guru" placeholder="Ketikan nama" value="<?php echo $row['nama'] ?>" class="form-control"></td>
							</tr> 
							<tr>
								<td><b>Password:</b></td>
								<td><input type="text" name="password"  placeholder="password" value="<?php echo $row['password'] ?>" class="form-control"></td>
							</tr>
							<tr>
								<td><b>Sesi:</b></td>
								<td>
									<select class="form-control" name="sesi" id="">
									<?php

								for($c=1; $c <= 40 ;$c++){
									if($c == $row['sesi']){
										echo '<option selected value="'.$c.'">'.$c.'</option>';
									}else{
										echo '<option value="'.$c.'">'.$c.'</option>';
									}
								}

									?>
								</select></td>
							</tr>

						</table>
						
						<div class="form-group">
							<button onclick="return confirm('Apakah anda yakin ingin mengubah? ')" type="submit" name="edit" class="btn btn-block btn-success">Simpan perubahan</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

			<?php

		}else{
				echo '<script>alert("Opps data tersebut sudah tidak ada");document.location.href="?module=guru"</script>';
		}
	}
}else{
	echo '<script>alert("Ada kesalahan");document.location.href="?module=guru"</script>';
}

	 ?>
	