
<br><br>
<h4>IMPORT SISWA DARI EXCEL</h4>
<hr>
<?php 
/**
 * File import excel ka database
 * @author dadan hidayat
 */
//manggil file koneksi ke database
include "../koneksi.php";
//manggill library simplexlsx jangen ngaimport data ti excel
include( "vendor/simplexlsx/src/SimpleXLSX.php" );
//cek hela aya data nu di uplod te
if(isset($_FILES['excel'])){
  //mun aya cek extensi na
 $extension = pathinfo($_FILES['excel']['name'],PATHINFO_EXTENSION);
 //lamun ektensi na xlsx lanjutken proses import data ka database
if($extension ==  'xlsx'){
  //cokot file nu di upload ti penyimpanan sementara php
  $xlsxfile = $_FILES['excel']['tmp_name'];
  //parse data na
  if($xlsx = SimpleXLSX::parse($xlsxfile)){
    //cek hela aya sabaraha baris data na
    //mun lewih ti hiji berarti bagus mn kurang berarti tidak bagus wkwkww
    if(count($xlsx->rows()) > 0){
      //simpen sebagai array(da emang array sih)
     $rows=$xlsx->rows();
     //hapus element array pertama karena urang ngan butuh data na saja
     array_shift($rows);
    
      //proses import data ka database tapi sebelum di eksport data na cek hela filena duplikat teu
     foreach( $rows as $data ) {
        //nyeien password acak
      $password = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdesfgijklmnopqrstuvwxyz0987654321");
      $pass  = "";
       //nagrti meren ie jangen naon
        for($i = 0; $i <= 5;$i++){
          $pass .= $password[$i];
        }
      
        //jangen nyien kode uniq guru
        $kodeguru = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdesfgijklmnopqrstuvwxyz0987654321");
        $kg  = "guru";
       //nagrti meren ie jangen naon
        for($i = 0; $i <= 5;$i++){
          $kg .= $kodeguru[$i];
        }
      if( $konek->query(sprintf("INSERT INTO tb_guru (kode_guru,nama,password,sesi) VALUES ('%s','%s','%s','%s')",$kg,$data[1],$pass,$data[2]))){
        //mn data berhasil di import tampilken pesan ie
        $ms = "<p class=\"alert alert-success\">Berhasil mengimport data</p>";
      }else{
        //man gagal nga import data tampilken pesan ie
        $ms = "<p class=\"alert alert-danger\">Gagal mengimport data: ".$konek->error."</p>";
      }
     }  
    }
  }
} else{
  //mun file na lain xlsx tampilken pesan
  $ms = $ms = "<p class=\"alert alert-info\">Format file harus xlsx</p>";

}
}
echo isset($ms) ? $ms :"";
?>
<form method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="file">Pilih file (xlsx)</label>
    <input type="file" id="file" name="excel" accept="vnd.ms.excel/xlsx" class="form-control">
    <span id="e"></span>
  </div>
  <button type="submit">Proses</button>
</form>
