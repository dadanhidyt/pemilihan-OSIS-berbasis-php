

<div class="row">
	<div class="col-lg-12">
		<div class="page-header"><h3>Edit data sesi</h3></div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<a href="?module=sesi"  class="btn btn-warning"><i class="fa fa-backward"></i> Kembali</a>
<br>
<br>
<?php 

//cokot id sesi nu rek di edit lewat parameter url
if(isset($_GET['sesi_id']) && !empty($_GET['sesi_id'])){
	$id = strip_tags($_GET['sesi_id']);
	//update data
	if( isset($_POST['edit']) ) {
		$nama_sesi = $konek->real_escape_string(htmlspecialchars($_POST['nama_sesi']));
		$dari = $konek->real_escape_string(htmlspecialchars($_POST['dari']));
		$sampai = $konek->real_escape_string(htmlspecialchars($_POST['sampai']));
		$hari = $konek->real_escape_string(htmlspecialchars($_POST['hari']));		
		if( $konek->query("UPDATE tb_sesi SET nama_sesi='$nama_sesi',mulai='$dari',akhir='$sampai',hari='$hari' WHERE id_sesi='$id'" ) ){
			echo "<script>alert('Update data berhasil')</script>";
		}else{
			echo $konek->error;
		}
	}
//ambil data
	if($gk = $konek->query("SELECT * FROM tb_sesi WHERE id_sesi='$id'")){
		if($gk->num_rows ==1){
			$row = $gk->fetch_assoc();
			?>

			<div class="row">
				<div class="col-md-5">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5>Detail</h5>
						</div>
						<div class="panel-body">
							<table class="table table-user-information">
								<tr>
									<td><b>Nama sesi:</b></td>
									<td>Sesi <?php echo $row['nama_sesi'] ?></td>
								</tr>
								<tr>
									<td><b>Jam mulai:</b></td>
									<td><?php echo $row['mulai'] ?></td>
								</tr>
								<tr>
									<td><b>Sampai:</b></td>
									<td><?php echo $row['akhir'] ?></td>
								</tr>
								<tr>
									<td><b>Hari:</b></td>
									<td><?php echo $row['hari'] ?></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<!-- bok edit sisi -->
				<div class="col-md-7">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5>EDIT SESI</h5>
						</div>
						<div class="panel-body">
							<form action="" method="POST">
								<table class="table">
									<tr>
										<td><b>Nama_sesi:</b></td>
										<td><input type="number" name="nama_sesi" placeholder="Nama sesi" value="<?php echo $row['nama_sesi'] ?>" class="form-control"></td>
									</tr>
									<tr>
										<td><b>Dari jam:</b></td>
										<td><input type="time" name="dari"  placeholder="Edit nis" value="<?php echo $row['mulai'] ?>" class="form-control"></td>
									</tr> 
									<tr>
										<td><b>Sampai jam:</b></td>
										<td><input type="time" name="sampai"  placeholder="password" value="<?php echo $row['akhir'] ?>" class="form-control"></td>
									</tr>
									<tr>
										<td><b>Hari:</b></td>
										<td>
											<select class="form-control" name="hari" id="hari">
												<?php 
												//hari indonesia
												$hari = 	array(
													1=>'Senin',
													'Selasa',
													'Rabu',
													'Kamis',
													'Jumat',
													'Sabtu',
													'Minggu'
												);
												//proses iterasi hari indonesia
												foreach($hari as $h){
													if(ucfirst($row['hari']) == ucfirst($h)){
														?>
														<option selected value="<?php echo ucfirst($h) ?>"><?php echo ucfirst($h) ?></option>
														<?php
													}else{
														?>
														<option value="<?php echo ucfirst($h) ?>"><?php echo ucfirst($h) ?></option>

														<?php
													}
												}
												?>

											</select>
										</td>
									</tr>
								</table>

								<div class="form-group">
									<button onclick="return confirm('Apakah anda yakin ingin mengubah? ')" type="submit" name="edit" class="btn btn-block btn-primary">Simpan perubahan</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>

			<?php

		}else{
			echo '<script>alert("Opps data tersebut sudah tidak ada");document.location.href="?module=sesi"</script>';
		}
	}
}else{
	echo '<script>alert("Ada kesalahan");document.location.href="?module=siswa"</script>';
}

?>
