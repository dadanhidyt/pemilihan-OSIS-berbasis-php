
<br><br>
<h4>IMPORT SESI DARI EXCEL</h4>
<hr>
<?php 
/**
 * File import excel ka database
 * @author dadan hidayat
 */
//manggil file koneksi ke database
include "../koneksi.php";
//manggill library simplexlsx jangen ngaimport data ti excel
include( "vendor/simplexlsx/src/SimpleXLSX.php" );
//cek hela aya data nu di uplod te
if(isset($_FILES['file_excel'])){
  //mun aya cek extensi na
 $extension = pathinfo($_FILES['file_excel']['name'],PATHINFO_EXTENSION);
 //lamun ektensi na xlsx lanjutken proses import data ka database
 if($extension ==  'xlsx'){
  //cokot file nu di upload ti penyimpanan sementara php
  $xlsxfile = $_FILES['file_excel']['tmp_name'];
  //parse data na
  if($xlsx = SimpleXLSX::parse($xlsxfile)){
    $rowss = $xlsx->rows();
    unset($rowss[0]);
    foreach($rowss as $sesi){
      $nama_sessi = (int)$sesi[1];
      $mulai = $sesi[2];
      $akhir = $sesi[3];
      $hari = $sesi[4];
     if($konek->query("INSERT INTO tb_sesi VALUES(null,'$nama_sessi','$mulai','$akhir','".$hari."')")){
      $ms ="<p class=\"alert alert-info\">Sukses mengimport data</p>";
    }else{
      $ms ="<p class=\"alert alert-info\">Gagal mengimport data ".$konek->error."</p>";

    }
  }
}else{
  $ms = "<p class=\"alert alert-danger\">".SimpleXLSX::parseError()."</p>";
}
} else{
  //mun file na lain xlsx tampilken pesan
  $ms ="<p class=\"alert alert-info\">Format file harus xlsx</p>";

}
}
echo isset($ms) ? $ms :"";
?>
<form method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="file">Pilih file (xlsx)</label>
    <input requied type="file" id="file" name="file_excel" accept="vnd.ms.excel/xlsx" class="form-control">
    <span id="e"></span>
  </div>
  <button type="submit">IMPORT</button>
</form>
