<?php
if(isset($_POST['tambah_siswa']) && !empty($_POST)){

  $nama = $konek->real_escape_string(htmlspecialchars($_POST['nama_siswa']));
  $kelas = $konek->escape_string(htmlspecialchars($_POST['kelas']));
  $nis = $konek->escape_string(htmlspecialchars($_POST['nis']));
  $password = $konek->escape_string(htmlspecialchars($_POST['password']));
  $sesi = $konek->escape_string(htmlspecialchars($_POST['sesi']));

  $tambahken = $konek->query("INSERT INTO tb_siswa (
    nama_siswa,
    nis_siswa,
    password,
    kelas_siswa,
    sesi
  ) VALUES (
    '$nama',
    '$nis',
    '$password',
    '$kelas',
    '$sesi'
  )");
  if($tambahken){
    echo "<script>alert('Berhasil menambahkan data');window.location.href='?module=siswa'</script>";
  }else{
    echo "<script>alert('Gagal menambahkan data');window.location.href='?module=siswa'</script>";
  }

}else{
  echo "<script>window.location.href='?module=siswa'</script>";

}