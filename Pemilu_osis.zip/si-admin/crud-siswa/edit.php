

<div class="row">
	<div class="col-lg-12">
		<div class="page-header"><h3>Edit data siswa</h3></div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<a href="?module=siswa"  class="btn btn-warning">Kembali</a>
<br>
<br>
<?php 


if(isset($_GET['data-id']) && !empty($_GET['data-id'])){
	$id = strip_tags($_GET['data-id']);
	//update data
	if( isset($_POST['edit']) ) {
		$nama = $konek->real_escape_string(htmlspecialchars($_POST['nama_siswa']));
		$nis = $konek->real_escape_string(htmlspecialchars($_POST['nis']));
		$password = $konek->real_escape_string(htmlspecialchars($_POST['password']));
		$kelas = $konek->real_escape_string(htmlspecialchars($_POST['kelas']));
		$sesi = $konek->real_escape_string(htmlspecialchars($_POST['sesi']));
		
		if( $konek->query("UPDATE tb_siswa SET nama_siswa='$nama',nis_siswa='$nis',password='$password',kelas_siswa='$kelas',sesi='$sesi' WHERE id_siswa='$id'" ) ){
			echo "<script>alert('Update data berhasil')</script>";
		}else{
			echo $konek->error;
		}
	}
//ambil data
	if($gk = $konek->query("SELECT * FROM tb_siswa WHERE id_siswa='$id'")){
		if($gk->num_rows ==1){
			$row = $gk->fetch_assoc();
			?>

			<div class="row">
				<div class="col-md-5">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5>Detail</h5>
						</div>
						<div class="panel-body">
							<table class="table table-user-information">
								<tr>
									<td><b>Nama:</b></td>
									<td><?php echo $row['nama_siswa'] ?></td>
								</tr>
								<tr>
									<td><b>Nis:</b></td>
									<td><?php echo $row['nis_siswa'] ?></td>
								</tr>
								<tr>
									<td><b>Password:</b></td>
									<td><?php echo $row['password'] ?></td>
								</tr>
								<tr>
									<td><b>Kelas:</b></td>
									<td><?php echo $row['kelas_siswa'] ?></td>
								</tr>
								<tr>
									<td><b>Sesi:</b></td>
									<td><?php echo $row['sesi'] ?></td>
								</tr>
								<tr>
									<td><b>Sudah memilih:</b></td>
									<td><?php echo $row['sudah_memilih'] == "Y" ? "<font color='green'>Sudah</font>" : "<font color='red'>Belum</font>"  ?></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-7">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5>EDIT SISWA</h5>
						</div>
						<div class="panel-body">
							<form action="" method="POST">
								<table class="table">
									<tr>
										<td><b>Nama:</b></td>
										<td><input type="text" name="nama_siswa" placeholder="Ketikan nama baru" value="<?php echo $row['nama_siswa'] ?>" class="form-control"></td>
									</tr>
									<tr>
										<td><b>Nis:</b></td>
										<td><input type="number" name="nis"  placeholder="Edit nis" value="<?php echo $row['nis_siswa'] ?>" class="form-control"></td>
									</tr> 
									<tr>
										<td><b>Password:</b></td>
										<td><input type="text" name="password"  placeholder="password" value="<?php echo $row['password'] ?>" class="form-control"></td>
									</tr>
									<tr>
										<td><b>Kelas:</b></td>
										<td><input  placeholder="Ketikan kelas" name="kelas" value="<?php echo $row['kelas_siswa'] ?>" type="text" class="form-control"></td>
									</tr>
									<tr>
										<td><b>Sesi:</b></td>
										<td>
											<select class="form-control" name="sesi" id="">
												<?php

												if($f = $konek->query("SELECT * FROM tb_sesi")){
													if($f->num_rows > 0){
														while($fs =  $f->fetch_object()){
															if($fs->nama_sesi == $row['sesi']){
																echo '<option selected value="'.$fs->nama_sesi.'">'.$fs->nama_sesi.'</option>';
															}else{
																echo '<option value="'.$fs->nama_sesi.'">'.$fs->nama_sesi.'</option>';
															}
														}
													}
												}

												?>
											</select></td>
										</tr>

									</table>
									
									<div class="form-group">
										<button onclick="return confirm('Apakah anda yakin ingin mengubah? ')" type="submit" name="edit" class="btn btn-block btn-success">Simpan perubahan</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>

				<?php

			}else{
				echo '<script>alert("Opps data tersebut sudah tidak ada");document.location.href="?module=siswa"</script>';
			}
		}
	}else{
		echo '<script>alert("Ada kesalahan");document.location.href="?module=siswa"</script>';
	}

	?>
	