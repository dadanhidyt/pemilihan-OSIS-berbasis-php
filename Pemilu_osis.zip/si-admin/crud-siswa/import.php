
<br><br>
<h4>IMPORT SISWA DARI EXCEL</h4>
<hr>
<?php 
/**
 * File import excel ka database
 * @author dadan hidayat
 */
//manggil file koneksi ke database
include "../koneksi.php";
//manggill library simplexlsx jangen ngaimport data ti excel
include( "vendor/simplexlsx/src/SimpleXLSX.php" );
//cek hela aya data nu di uplod te
if(isset($_FILES['file_excel'])){
  //mun aya cek extensi na
 $extension = pathinfo($_FILES['file_excel']['name'],PATHINFO_EXTENSION);
 //lamun ektensi na xlsx lanjutken proses import data ka database
if($extension ==  'xlsx'){
  //cokot file nu di upload ti penyimpanan sementara php
  $xlsxfile = $_FILES['file_excel']['tmp_name'];
  //parse data na
  if($xlsx = SimpleXLSX::parse($xlsxfile)){
    //cek hela aya sabaraha baris data na
    //mun lewih ti hiji berarti bagus mn kurang berarti tidak bagus wkwkww
    if(count($xlsx->rows()) > 0){
      //simpen sebagai array(da emang array sih)
     $rows=$xlsx->rows();
     //hapus element array pertama karena urang ngan butuh data na saja
     array_shift($rows);
    
      //proses import data ka database tapi sebelum di eksport data na cek hela filena duplikat teu
     foreach( $rows as $data ) {
      //nyeien password acak
      $password = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdesfgijklmnopqrstuvwxyz0987654321");
      $pass  = "";
      //nagrti meren ie jangen naon
        for($i = 0; $i <= 5;$i++){
          $pass .= $password[$i];
        }
      if(@mysqli_num_rows($konek->query("SELECT nis_siswa FROM tb_siswa WHERE nis_siswa='".$data[1]."'")) == 1){
        $ms = "<p class=\"alert alert-warning\">Data sudah ada di database! Tidak bisa di import dua kali</p>";
       }else{
        if( $konek->query(sprintf("INSERT INTO tb_siswa (nama_siswa,nis_siswa,password,kelas_siswa,sesi) VALUES ('%s','%s','%s','%s','%s')",$data[0],$data[1],$pass,$data[2],$data[3]))){
          //mn data berhasil di import tampilken pesan ie
          $ms = "<p class=\"alert alert-success\">Berhasil mengimport data</p>";
        }else{
          //man gagal nga import data tampilken pesan ie
          $ms = "<p class=\"alert alert-danger\">Gagal mengimport data: ".$konek->error."</p>";
        }
       }
     }      
    }
  }
} else{
  //mun file na lain xlsx tampilken pesan
  $ms = $ms = "<p class=\"alert alert-info\">Format file harus xlsx</p>";

}
}
echo isset($ms) ? $ms :"";
?>
<form method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="file">Pilih file (xlsx)</label>
    <input type="file" id="file" name="file_excel" accept="vnd.ms.excel/xlsx" class="form-control">
    <span id="e"></span>
  </div>
  <button type="submit" onclick="proses(this)">Proses</button>
</form>
