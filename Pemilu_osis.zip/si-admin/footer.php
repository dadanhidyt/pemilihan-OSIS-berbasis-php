<?php
//manggil file perolehan suara nu esina hasil pemilihan
if(isset($_GET['action']) && $_GET['action'] == 'tambah'){
  echo '<script src="../assets/vendor/tinymce/tinymce.min.js"></script>';
  ?>
<script>
//jangen tinymce
tinymce.init({
  selector: "#deskripsicalon",
  width: '100%',
  height: 200
})
</script>
<?php
}elseif(isset($_GET['action']) && $_GET['module'] == 'calon' && $_GET['action']=='edit'){
  echo '<script src="../assets/vendor/tinymce/tinymce.min.js"></script>';
  ?>
<script>
tinymce.init({
  selector: "#edit",
  width: '100%',
  height: 100
})
</script>
<?php
}
?>
<!-- jQuery -->
<script src="assets/js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="assets/js/metisMenu.min.js"></script>

<?php
if(isset($_GET['module'])){
 if($_GET['module'] == "beranda"){
   ?>
<!-- Morris Charts JavaScript -->
<script src="assets/js/raphael.min.js"></script>
<script src="assets/js/morris.min.js"></script>
<script>
Morris.Donut({
  element: 'morris-donut-chart',
  data: [<?php Moris_Data('donut') ?>],
  resize: true
});

Morris.Bar({
  element: 'morris-bar-chart',
  data: [<?php Moris_Data('bar') ?>],
  xkey: 'y',
  ykeys: ['a'],
  labels: ['Total Suara'],
  hideHover: 'auto',
  resize: true
});
</script>
<?php

}elseif($_GET['module'] == 'siswa' OR $_GET['module'] == "guru" OR $_GET['module'] =='sesi' OR $_GET['module'] == "calon"){
 ?>

<script src="assets/js/dataTables/jquery.dataTables.min.js"></script>
<script src="assets/js/dataTables/dataTables.bootstrap.min.js"></script>

<?php
}else{
 ?>
<!-- Morris Charts JavaScript -->
<script src="assets/js/raphael.min.js"></script>
<script src="assets/js/morris.min.js"></script>
<?php
}
}else{
  ?>
<!-- Morris Charts JavaScript -->
<script src="assets/js/raphael.min.js"></script>
<script src="assets/js/morris.min.js"></script>
<script>
Morris.Donut({
  element: 'morris-donut-chart',
  data: [<?php Moris_Data('donut') ?>],
  resize: true
});

Morris.Bar({
  element: 'morris-bar-chart',
  data: [<?php Moris_Data('bar') ?>],
  xkey: 'y',
  ykeys: ['a'],
  labels: ['Total Suara'],
  hideHover: 'auto',
  resize: true
});
</script>
<?php
}

?>

<!-- Custom Theme JavaScript -->
<script src="assets/js/startmin.js"></script>
<script>
<?php 

  if(isset($_GET['module'])){
    if($_GET['module'] == 'siswa'){
      ?>
$(document).ready(function() {
  $('#dataTables-siswa').DataTable({
    responsive: true
  });
});

<?php
    }elseif($_GET['module'] == "guru"){
      ?>

$(document).ready(function() {
  $('#dataTables-guru').DataTable({
    responsive: true
  });
});

<?php

    }elseif($_GET['module'] == 'sesi'){
      ?>
$(document).ready(function() {
  $('#dataTables-sesi').DataTable({
    responsive: true
  });
});
<?php
    }elseif($_GET['module'] == 'calon'){
      ?>
$(document).ready(function() {
  $('#dataTables-calon').DataTable({
    responsive: true
  });
});
<?php
    }
  }
  ?>
</script>
<?php
if(isset($_GET['module']) && $_GET['module']=='hasil_pemilihan'){
  include_once("includes/hasil_perhitungan_suara.php");
  ?>

  <script src="assets/js/flot/excanvas.min.js"></script>
   <script src="assets/js/flot/jquery.flot.js"></script>
   <script src="assets/js/flot/jquery.flot.pie.js"></script>
   <script src="assets/js/flot/jquery.flot.resize.js"></script>
   <script src="assets/js/flot/jquery.flot.time.js"></script>
   <script src="assets/js/flot/jquery.flot.tooltip.min.js"></script>
  <script>
//Flot Pie Chart
$(function () {

var data = [
  <?php
    
    foreach(Perolehan() as $p){
      ?>
      
          {
            label: "<?= $p['Nama_calon'] ?>",
            data: <?= $p['Persen'] ?>,
          },
      
      <?php
    }
    
    ?>
  
];
//CHART PIE
    var plotObj = $.plot($("#CHART-PIE-HASIL-PEMILIHAN"), data, {
        series: {
            pie: {
                show: true
            }
        },
        grid: {
            hoverable: true
        },
        tooltip: true,
        tooltipOpts: {
            content: "%p.2%, %s", // show percentages, rounding to 2 decimal places
            shifts: {
                x: 20,
                y: 0
            },
            defaultTheme: false
        }
    });

    });

  </script>
   <?php


   ?>
  
  
  <?php
}

?>
</body>

</html>