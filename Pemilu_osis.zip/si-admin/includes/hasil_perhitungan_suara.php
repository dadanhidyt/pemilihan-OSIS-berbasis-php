<?php
/**
 * @author dadan hidayat
 */
include("../koneksi.php");
//total suara keseluruhan
function TotalSuara(){
  global $konek;
  //mengambil semua toal suara seluruh calon
  return $konek->query("SELECT * FROM tb_suara")->num_rows;
}

//fungsi jangen ubah ke persen
function KePersen($bil1,$bil2){

  return $bil1*100/$bil2;

}
//fungsi jangen nampung jumlah perolehan suara per calon

function Perolehan(){
  global $konek;
  $calon = $konek->query("SELECT * FROM tb_calon");
 if($calon->num_rows>0){
  while($c = $calon->fetch_object()){
    $data[] = array(
      "No_calon"=>$c->no_calon,
      "Nama_calon"=>$c->Nama_calon,
      "Persen"=>round(KePersen($konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$c->no_calon."'")->num_rows,TotalSuara()),2),
      "TotalSuara"=>$konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$c->no_calon."'")->num_rows
    );
   }
 }else{
  $data[] = array(
    "No_calon"=>1,
    "Nama_calon"=>"Contoh1",
    "Persen"=>1,
  );
  $data[] = array(
    "No_calon"=>1,
    "Nama_calon"=>"Contoh2 ",
    "Persen"=>1,
  );
 }
  return $data;
}
