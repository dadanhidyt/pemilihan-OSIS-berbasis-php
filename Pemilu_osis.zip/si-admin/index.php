<?php
date_default_timezone_set("Asia/Jakarta");
session_start();
if(!isset($_SESSION['admin_login'])){
  header('location:login.php');
  exit;
}
//manggil file koneksi
include("../koneksi.php");
//manggil file header
include("admin-html-header.php");
//manggil file navbar
include("nav.php");
include("perolehanSuara.php");
updatePerolehanSuara();
echo "<div id='page-wrapper'><div class='container-fluid'>";
//basic routing admin 
if(isset($_GET['module'])){
  $module = filter_var($_GET['module'],FILTER_SANITIZE_STRING);
  switch($module){
    case "beranda":
    include "module/beranda.php";
    break;
    case "pengaturan":
    include "module/setting.php";
    break;
    case "siswa":
    include "module/data-siswa.php";
    break;
    case "guru":
    include "module/data-guru.php";
    break;
    case "sesi":
    include "module/data-sesi.php";
    break;
    case "calon":
    include("module/data-calon.php");
    break;
    case "laporan":
    include("module/laporan.php");
    break;
    case"setting":
      include("module/setting.php");
      break;
    case"hasil_pemilihan":
      include("module/hasil.php");
      break;
    case "logout":
    unset($_SESSION['admin_login']);
    unset($_SESSION['admin_id']);
    echo '<script>window.location.href="login.php"</script>';
    exit;
    break;
    default:
    include "module/beranda.php";

  }
}else{
  include "module/beranda.php";
}
echo "</div></div>";
include("footer.php");
?>