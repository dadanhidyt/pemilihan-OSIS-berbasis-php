<?php
//membuat session
session_start();
//jangen ngecek admin ges login atawa acan
//lamun enges login arahken ka halaman beranda
if(isset($_SESSION['admin_login']) && $_SESSION['admin_login'] == true){
  header('location:index.php?module=beranda');
  exit;
}
//halaman login
$title = "Login Admin";
//memanggil file koneksi
include '../koneksi.php';
//manggil file header
include "admin-html-header.php";
//common function
include "../code/comon.function.php";
//lamun tombbol login di pencet
if(isset($_POST['login'])){
  $csrf = strip_tags($_POST['csrf']);
  if($_SESSION['csrf']==$csrf){
   $email = strip_tags(stripslashes($konek->escape_string($_POST['email'])));
   $password = md5(stripslashes($konek->escape_string($_POST['password'])));
   if($cokot = $konek->query("SELECT * FROM tb_admin WHERE email='$email' && password='$password'")){
    if($cokot->num_rows == 1){
      //cokot data admin nu login na
      $admindata = $cokot->fetch_object();
      $_SESSION['admin_login'] = true;
      $_SESSION['admin_id'] = $admindata->id;
      echo "<script>alert('Welcome back!!! Kamu berhasil login');window.location.href='index.php?module=beranda'</script>";
    }else{
      echo "<script>alert('Kesalahan saat Login!!! Email dan password tidak di temukan');window.location.href='login.php'</script>";
    }
  }
}
}
?>
<div class="container">
  <div class="row">
    <div class="col-md-4 col-md-offset-4">
     <div class="login-panel panel panel-default">
       <div class="panel-heading">
        <h3 class="panel-title">LOGIN KE ADMIN</h3>
      </div>
      <div class="panel-body">
       <form method="POST"  role="form">
        <fieldset>
          <input type="hidden" value="<?php echo generateCsrf() ?>" name="csrf">
          <div class="form-group">   
           <label for="email">Email</label>
           <input required autocomplete="off" autofocus="on" class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
         </div>
         <div class="form-group">
          <label for="password">Password</label>
          <input required autocomplete="off" autofocus="on" class="form-control" placeholder="Password" name="password" type="password" value="">
        </div>
        <!-- Change this to a button or input when using this as a form -->
        <button name="login" class="btn btn-block btn-primary">login</button>
      </fieldset>
    </form>
  </div>
</div>
</div>
</div>
</div>
</body>
</html>