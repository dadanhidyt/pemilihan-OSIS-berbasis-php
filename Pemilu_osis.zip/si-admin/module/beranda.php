<div class="row">
  <div class="col-lg-12">
      <h4 class="page-header">BERANDA</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-percent fa-5x"></i>
                    </div>
                    <?php
                    //hitung sakabeh siswa jeng hitung sabaraha urang nu ges mi
                    $sudah = mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE sudah_memilih='Y'"))+mysqli_num_rows($konek->query("SELECT * FROM tb_guru WHERE sudah_memilih='Y'"));
                    $belum = mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE sudah_memilih='N'"))+mysqli_num_rows($konek->query("SELECT * FROM tb_guru WHERE sudah_memilih='N'"));;
                    $siswadanguru = mysqli_num_rows($konek->query("SELECT * FROM tb_siswa"))+mysqli_num_rows($konek->query("SELECT * FROM tb_guru"));
                    if($siswadanguru > 0 && $sudah > 0){
                        $presen = round($sudah*100/$siswadanguru);
                    }else{
                        $presen = 0;
                    }
                    ?>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= $presen ?>%</div>
                        <div>Sudah memilih!</div>
                    </div>
                </div>
            </div>
            <a href="#">
                <div class="panel-footer">
                    <span class="pull-left">Selangkapnya</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-calculator fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= number_format($siswadanguru) ?></div>
                        <div>Total siswa + guru</div>
                    </div>
                </div>
            </div>
            <a href="#">
                <div class="panel-footer">
                    <span class="pull-left">Selangkapnya</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-check-circle-o fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= $sudah ?></div>
                        <div>Sudah memilih</div>
                    </div>
                </div>
            </div>
            <a href="#">
                <div class="panel-footer">
                    <span class="pull-left">Selangkapnya</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-times-circle fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= $belum ?></div>
                        <div>Belum memilih</div>
                    </div>
                </div>
            </div>
            <a href="#">
                <div class="panel-footer">
                    <span class="pull-left">Selangkapnya</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
</div>
<?php
//nyertaken halaman chart didie
include "chart_hasil.php";

?>