<hr>
<div class="row">
    <div class="col-lg-8">
        <!-- /.panel -->
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-bar-chart-o fa-fw"></i> Hasil Pemilu
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="row">

                    <!-- /.col-lg-4 (nested) -->
                    <div class="col-lg-12">
                        <div id="morris-bar-chart"></div>
                    </div>
                    <!-- /.col-lg-8 (nested) -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->

    </div>
    <!-- /.col-lg-8 -->
    <div class="col-lg-4">

        <!-- /.panel -->
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-bar-chart-o fa-fw"></i> Hasil Pemilihan
            </div>
            <div class="panel-body">
                <div id="morris-donut-chart"></div>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->

        <!-- /.panel .chat-panel -->
    </div>
    <!-- /.col-lg-4 -->
</div>


