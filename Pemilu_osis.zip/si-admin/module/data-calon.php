<?php 
/*
*@author dadan hiayat
*/
define("calonpage",0);
//lamun aya parameter url action
if(isset($_GET['action'])){
  if($_GET['action'] == "edit"){
    include("crud-calon/edit.php");
  }elseif($_GET['action'] == "delete"){
    //cek hela aya parameter url id teu
   if(!empty($_GET['id_calon'])){
    //mun aya tugasken kana variabel idcalon nilaina
     $idcalon = $_GET['id_calon'];
     //mengambil dari tebel suara sesuai dengan parameter
     $gg = $konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$_GET['no_calon']."'");
     //iterasi hasil nya
     while( $rowgg=$gg->fetch_assoc() ) {
      //ubah ke belum milih jika siswa/guru milih salah satu calon yang akan di hapus
      $konek->query("UPDATE tb_siswa SET sudah_memilih='N' WHERE nis_siswa='".$rowgg['pemilih']."'");
      $konek->query("UPDATE tb_guru SET sudah_memilih='N' WHERE kode_guru='".$rowgg['pemilih']."'");
    }
     //hapus hela gambar calon na meh awet memori ;)
    @unlink("../images/foto-calon/".$konek->query("SELECT * FROM tb_calon WHERE id='$idcalon'")->fetch_assoc()['gambar_calon']);
     //proses hapus data calon berdasarkan id nu aya dina parameter
    if($konek->query("DELETE FROM tb_calon WHERE id='$idcalon'")){
      $noCalon = $_GET['no_calon'];
      //hapus oge di tabel tb_suara
      $konek->query("DELETE FROM tb_suara WHERE ke_calon='$noCalon'");
      //lamun datanya di hapus tampilken pesan iyeu di handap
      echo '<script>alert("Data berhasil di hapus");window.location.href="?module=calon"</script>';
    }else{
      //man gagal di
      echo '<script>alert("Data gagal di hapus karena aya kesalahan yang membuat sistem kesal");window.location.href="?module=calon"</script>';
    }
  }else{
    //man eweh parameter action arahken ka halaman calon
    echo '<script>window.location.href="?module=calon"</script>';
  }
}elseif($_GET['action'] == 'tambah'){
  include("crud-calon/tambah.php");
}else{
  echo '<script>window.location.href="?module=calon"</script>';
}
}else{
  ?>
  <div class="row">
    <div class="col-lg-12">
      <div class="page-header"><h3>Data Calon</h3></div>
    </div>
    <!-- /.col-lg-12 -->
  </div>
  <!-- data calon -->
  <div class="row">
    <div class="col-lg-12">
      <div class="col-md-6">
        <div class="row">
          <a class="btn btn-primary" href="?module=calon&action=tambah">Tambah <i class="fa fa-plus-circle"></i></a> |  <a href="print.php?print=pemilihan" class="btn btn-success">Cetak <i class="fa fa-download"></i></a>
        </div>
      </div>
      <br>
      <br>
      <div class="panel panel-default">
        <div class="panel-heading">
          Data calon
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered" width="100%" id="dataTables-calon">
              <thead>
                <tr>
                  <th>NO</th>
                  <th width="100">No Calon</th>
                  <th width="100">Nama calon</th>
                  <th>Deskripsi</th>
                  <th>Suara</th>
                  <th>FOTO</th>
                  <th>ACTION</th>
                </tr>
              </thead>
              <tbody>
               <?php
               
               if($g = $konek->query("SELECT * FROM tb_calon")){
                $no = 0;
                                //nampilken
                while($row = $g->fetch_object()){
                  $no++;
                  ?>
                  <tr class="odd gradeX">
                    <td style="text-align: center;"><?= $no ?></td>
                    <td style="text-align:center;"><?= ucfirst(strtolower($row->no_calon)) ?></td>
                    <td><?= ucfirst(strtolower($row->Nama_calon)) ?></td>
                    <td><?= htmlspecialchars_decode($row->deskripsi) ?></td>
                    <td style="text-align: center;"><?= $row->jumlah_suara ?></td>
                    <td><img width="100px" style="border-radius: 10px;box-shadow: 0px 0px 0px 2px #dedede" src="../images/foto-calon/<?php echo $row->gambar_calon ?>" alt=""></td>
                    <td width="100">
                      <a  href="?module=calon&action=edit&id_calon=<?php echo $row->id ?>" class="btn btn-block btn-primary">EDIT</a> <br>
                      <a onclick="return confirm('Apakah anda yakin dengan tindakan ini?')"  href="?module=calon&action=delete&no_calon=<?= $row->no_calon ?>&id_calon=<?= $row->id ?>" class="btn btn-block btn-danger">Hapus</a>
                    </td>
                  </tr>
                  <?php
                }
              }
              ?>
            </tbody>
          </table>
        </div>
        <!-- /.table-responsive -->
      </div>
      <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
  <!-- /.col-lg-12 -->
</div>


<?php
}


?>