<?php
/**
 * @author dadan hidayat
 */
//cek hela aya eweh parameter action
if( isset( $_GET['action'] )){
    //jangen import excel
    if( $_GET['action']=="import_excel" ){
        //mun parameter na import excel lakuken fungsi di handap iyeu
        include('crud-guru/import.php');
    }elseif($_GET['action'] == "edit"){
        include("crud-guru/edit.php");
    //jangen hapus data
    }elseif($_GET['action']=='delete'){
        if(isset($_GET['id_guru']) && !empty($_GET['id_guru'])){
            $id_guru = $konek->escape_string($_GET['id_guru']);
            if($konek->query("DELETE FROM tb_guru WHERE id_guru='$id_guru'")){
             echo "<script>alert('Data berhasil di hapus');document.location.href='?module=guru'</script>";
         }
     }
    //jangen tambah data
 }elseif( $_GET['action']=='tambah' ){

     if( isset($_POST['tambah']) ){
         if(empty($_POST)){
            echo "<script>alert('Gagal menambahkan data! Folmulir masih kosong');document.location.href='?module=guru'</script>";
        }else{
            //simpen data nu di kirim ka variabel
         $nama = htmlspecialchars(strip_tags($_POST['nama_guru']));
         $password = htmlspecialchars(strip_tags($_POST['password']));
         $sesi = htmlspecialchars(strip_tags($_POST['sesi']));
         $kodeguru = strtoupper("guru-".substr(md5(uniqid()),0,5));
         if($konek->query("INSERT INTO tb_guru (kode_guru,nama,password,sesi) VALUES ('$kodeguru','$nama','$password','$sesi')")){
            echo "<script>alert('Berhasil menambahkan data');document.location.href='?module=guru'</script>";
        } else{
            echo "<script>alert('Gagal menambahkan data! ".$konek->error."');document.location.href='?module=guru'</script>";
        }
    }
}else{
    //lamun eweh parameter arahken ka halaman guru
    echo "<script>document.location.href='?module=guru'</script>";
}
}
}else{
    ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="page-header"><h3>Data Guru</h3></div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="col-md-6">
                <div class="row">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-data-guru">Tambah <i class="fa fa-plus-circle"></i></button> |  <a href="?module=guru&action=import_excel" class="btn btn-danger">Import <i class="fa fa-upload"></i></a> |  <a target="__blank" href="print.php?print=data_guru&with_download" class="btn btn-success">Cetak <i class="fa fa-download"></i></a>
                </div>
            </div>
            <!-- modal tambah data -->
            
            <!-- Modal -->
            <div class="modal fade" id="tambah-data-guru" tabindex="-1" role="dialog" aria-labelledby="tambah-data-guru" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times-circle"></i></button>
                            <h4 class="modal-title" id="myModalLabel">Tambah data guru</h4>
                        </div>
                        <div class="modal-body">

                            <!-- form -->
                            <form action="?module=guru&action=tambah" method="post">
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input required autocomplete="off" type="text" placeholder="Masukan nama guru" name="nama_guru" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <?php
                                    $passwordguru = "";
                                    $shuffle = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789");
                                    for($es =0 ;$es<=5;$es++){
                                     $passwordguru .= $shuffle[$es];
                                 }
                                 ?>
                                 <input required autocomplete="off" type="text" readonly value="<?= $passwordguru ?>" name="password" class="form-control">
                             </div>
                             <div class="form-group">
                                <label for="nama">Sesi</label>
                                <input required autocomplete="off" type="number" name="sesi" placeholder="Sesi" class="form-control">
                            </div>
                            <div class="form-group">
                                <button name="tambah" class="btn btn-warning">Tambah</button>
                            </div>
                        </form>
                        <!-- ../form -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- ./end modal tambah data -->
        <br>
        <br>
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Guru
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered" width="100%" id="dataTables-guru">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NAMA</th>
                                <th>PASSWORD</th>
                                <th>SESI</th>
                                <th>STATUS</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php
                         if($g = $konek->query("SELECT * FROM tb_guru")){
                            $no = 0;
                                //nampilken
                            while($row = $g->fetch_object()){
                                $no++;
                                ?>
                                <tr class="odd gradeX">
                                    <td><?= $no ?></td>
                                    <td><?= ucfirst(strtolower($row->nama)) ?></td>
                                    <td><?= $row->password ?></td>
                                    <td><?= $row->sesi ?></td>
                                    <td><?= $row->sudah_memilih == "Y"? "<font color='green'>SUDAH MEMILIH</font>" : "<font color='red'>BELUM MEMILIH</font>" ?></td>
                                    <td width="240">
                                        <a  href="?module=guru&action=edit&id_guru=<?php echo $row->id_guru ?>" class="btn btn-primary">EDIT</a>
                                        <a onclick="return confirm('Apakah anda yakin dengan tindakan ini?')"  href="?module=guru&action=delete&id_guru=<?= $row->id_guru ?>" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
</div>
<!-- /.col-lg-12 -->
</div>

<?php
}
?>
