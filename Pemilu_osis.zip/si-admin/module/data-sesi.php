<?php 
if(isset($_GET['action']) && !empty($_GET['action'])){
  $action = $_GET['action'];
  switch($action){
    case 'edit':
    include("crud-sesi/edit.php");
    break;
    case 'delete':
    //id
    $idsesi = isset($_GET['sesi_id']) ? $_GET['sesi_id'] : false;
    if($idsesi){
      if($konek->query("DELETE FROM tb_sesi WHERE id_sesi='$idsesi'")){
        echo "<script>alert('Penghapusan data berhasil');window.location.href='?module=sesi'</script>";
      }
    }
    break;
    case 'import':
    include("crud-sesi/import.php");
    break;
    default:
    echo '404';
    break;
  }
}else{
  ?>

  <div class="row">
    <div class="col-lg-12">
      <div class="page-header"><h3>Data Sesi</h3></div>
    </div>
    <!-- /.col-lg-12 -->
  </div>
  <div class="row">
    <div class="col-lg-12">
      <div class="col-md-5">
        <div class="row">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-data-sesi">Tambah Sesi <i class="fa fa-plus-square"></i></button> |  <a href="?module=sesi&action=import" class="btn btn-danger">Import <i class="fa fa-upload"></i></a> |  <a target="__blank"  href="print.php?print=print_sesi&with_download" class="btn btn-success">Cetak <i class="fa fa-print"></i></a>
        </div>
      </div>
      <!-- Modal jangen tambah sesi -->
      <div class="modal fade" id="tambah-data-sesi" tabindex="-1" role="dialog" aria-labelledby="tambah-data-guru" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times-circle"></i></button>
              <h4 class="modal-title" id="myModalLabel">Tambah Sesi</h4>
            </div>
            <div class="modal-body">

              <!-- form jangen nambah guru -->
              <form action="?module=siswa&action=tambah_siswa" method="post">
                <div class="form-group">
                  <label for="nama">Sesi</label>
                  <input required type="text" autocomplete="off" placeholder="Ketikan nama" name="nama_sesi" class="form-control">
                </div>
                <div class="form-group">
                  <label for="awal">Jam awal</label>
                  <input required type="time" autocomplete="off" value="00:00" name="mulai" class="form-control">
                </div>
                <div class="form-group">
                  <label for="akhir">Sampai</label>
                  <input required type="time" autocomplete="off" value="00:00" name="akhir" class="form-control">
                </div>
                <div class="form-group">
                  <label for="hari">Hari</label>
                  <select class="form-control" name="hari" id="hari">
                    <?php 

                    $indohari = array(1=>'Senin',
                     'Selasa',
                     'Rabu',
                     'Kamis',
                     'Jumat',
                     'Sabtu',
                     'Minggu'
                   );
                    foreach($indohari as $hari){
                      ?>
                      <option value="<?= $hari ?>"><?= $hari ?></option>

                      <?php
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <button name="tambah_sesi" class="btn btn-primary btn-block">Tambah <i class="fa fa-plus-circle"></i></button>
                </div>
              </form>
              <!-- ../form -->
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- ./end modal tambah data -->
      <br>
      <br>
      <div class="panel panel-default">
        <div class="panel-heading">
          Data siswa
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered" width="100%" id="dataTables-sesi">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Sesi</th>
                  <th>Mulai</th>
                  <th>Sampai</th>
                  <th>Hari</th>
                  <th>ACTION</th>
                </tr>
              </thead>
              <tbody>
                <?php
                if($g = $konek->query("SELECT * FROM tb_sesi")){
                  $no = 0;
                                //nampilken
                  while($row = $g->fetch_object()){
                    $no++;
                    ?>
                    <tr class="odd gradeX">
                      <td><?= $no ?></td>
                      <td>Sesi <?= $row->nama_sesi ?></td>
                      <td><?= $row->mulai ?></td>
                      <td><?= $row->akhir ?></td>
                      <td><?=ucfirst( $row->hari) ?></td>
                      <td width="140">
                        <a  href="?module=sesi&action=edit&sesi_id=<?php echo $row->id_sesi ?>" class="btn btn-primary">EDIT</a>
                        <a onclick="return confirm('Apakah anda yakin dengan tindakan ini?')"  href="?module=sesi&action=delete&sesi_id=<?= $row->id_sesi?>" class="btn btn-danger">Hapus</a>
                      </td>
                    </tr>
                    <?php
                  }
                }
                ?>
              </tbody>
            </table>
          </div>
          <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
      </div>
      <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
  </div>
  <?php
}

?>
