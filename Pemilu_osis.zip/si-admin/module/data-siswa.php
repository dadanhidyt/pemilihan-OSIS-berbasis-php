
<?php
if(isset($_GET['action'])){
    if($_GET['action']=="import"){
        include('crud-siswa/import.php');
    }elseif($_GET['action'] == "edit"){
        include("crud-siswa/edit.php");
    }elseif($_GET['action']=='delete'){
        if(isset($_GET['data-id']) && !empty($_GET['data-id'])){
            $dataid = $konek->escape_string($_GET['data-id']);
            if($konek->query("DELETE FROM tb_siswa WHERE id_siswa='$dataid'")){
               echo "<script>alert('Data berhasil di hapus');document.location.href='?module=siswa'</script>";
           }
       }
   }elseif($_GET['action']=='tambah_siswa'){
       include "crud-siswa/tambah.php";
   }
}else{
    ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="page-header"><h3>Data siswa</h3></div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="col-md-5">
                <div class="row">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-data-siswa">Tambah <i class="fa fa-plus-square"></i></button> |  <a href="?module=siswa&action=import" class="btn btn-danger">Import <i class="fa fa-upload"></i></a> |  <a  href="print.php?print=data_siswa&kelas=all&with_download" class="btn btn-success">Cetak <i class="fa fa-print"></i></a>
                </div>
            </div>
            <!-- Modal jangen tambah siswa -->
            <div class="modal fade" id="tambah-data-siswa" tabindex="-1" role="dialog" aria-labelledby="tambah-data-guru" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times-circle"></i></button>
                            <h4 class="modal-title" id="myModalLabel">Tambah data Siswa</h4>
                        </div>
                        <div class="modal-body">

                            <!-- form jangen nambah guru -->
                            <form action="?module=siswa&action=tambah_siswa" method="post">
                                <div class="form-group">
                                    <label for="nama">Nama siswa</label>
                                    <input required type="text" autocomplete="off" placeholder="Ketikan nama" name="nama_siswa" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nis</label>
                                    <input required type="number" autocomplete="off" placeholder="Ketikan nis" name="nis" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Kelas</label>
                                    <input required type="text" placeholder="Ketikan kelas" name="kelas" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Password</label>
                                    <?php
                                    $passwordsiswa = "";
                                    $shuffle = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789");
                                    for($es =0 ;$es<=5;$es++){
                                     $passwordsiswa .= $shuffle[$es];
                                 }
                                 ?>
                                 <input required type="text" readonly value="<?= $passwordsiswa ?>" name="password" class="form-control">
                             </div>
                             <div class="form-group">
                                <label for="nama">Sesi</label>
                                <input required type="number" placeholder="Sesi" name="sesi" class="form-control">
                            </div>
                            <div class="form-group">
                                <button name="tambah_siswa" class="btn btn-primary btn-block">Tambah <i class="fa fa-plus-circle"></i></button>
                            </div>
                        </form>
                        <!-- ../form -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- ./end modal tambah data -->
        <br>
        <br>
        <div class="panel panel-default">
            <div class="panel-heading">
                Data siswa
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" width="100%" id="dataTables-siswa">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>NIS</th>
                                <th>KELAS</th>
                                <th>SESI</th>
                                <th>STATUS</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php
                           if($g = $konek->query("SELECT * FROM tb_siswa")){
                            $no = 0;
                                //nampilken
                            while($row = $g->fetch_object()){
                                $no++;
                                ?>
                                <tr class="odd gradeX">
                                    <td><?= $no ?></td>
                                    <td><?= ucfirst(strtolower($row->nama_siswa)) ?></td>
                                    <td><?= $row->nis_siswa ?></td>
                                    <td><?= $row->kelas_siswa ?></td>
                                    <td><?= $row->sesi ?></td>
                                    <td><?= $row->sudah_memilih == "Y"? "<font color='green'>SUDAH MEMILIH</font>" : "<font color='red'>BELUM MEMILIH</font>" ?></td>
                                    <td width="140">
                                        <a  href="?module=siswa&action=edit&data-id=<?php echo $row->id_siswa ?>" class="btn btn-primary">EDIT</a>
                                        <a onclick="return confirm('Apakah anda yakin dengan tindakan ini?')"  href="?module=siswa&action=delete&data-id=<?= $row->id_siswa ?>" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
</div>
<!-- /.col-lg-12 -->
</div>

<?php
}
?>
