<div class="row">
  <div class="col-md-12">
    <div class="page-header">
      <h4>HASIL PEMILIHAN</h4>
    </div>
  </div>
</div>
<div class="row">
<div class="col-lg-8">
    <div class="panel panel-default">
        <div class="panel-heading">
            HASIL PEMILIHAN (PERSEN)
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            <div class="flot-chart">
                <div class="flot-chart-content" id="CHART-PIE-HASIL-PEMILIHAN"></div>
            </div>
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
</div>
<!-- ringkasan total suara -->
<?php include_once("includes/hasil_perhitungan_suara.php");?>
<div class="col-md-4">
<div class="panel panel-default">
        <div class="panel-heading">
            HASIL PEMILIHAN
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
          <p>
            Total keseluruhan suara adalah <?= TotalSuara() ?> Suara Dari <?= $konek->query("SELECT * FROM tb_siswa")->num_rows ?> Jumlah siswa dan <?= $konek->query("SELECT * FROM tb_guru")->num_rows ?> Guru          </p>
        </div>
        <!-- /.panel-body -->
    </div>
</div>
</div>