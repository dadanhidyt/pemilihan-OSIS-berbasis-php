<div class="col-md-12">
  <div class="row">
    <div class="page-header">
      <b>LAPORAN</b>
    </div>
  </div>
</div>
<div class="col-md-12">
  <div class="row">
    <!-- panel -->
    <div class="panel panel-default">
      <div class="panel-heading">
        <b>LAPORAN</b>
      </div>
      <div class="panel-body">
        <!-- panel -->
        <button data-toggle="modal" data-target="#modal-download-siswa" class="btn btn-primary">CETAK/DOWNLOAD LAPORAN</button>
              <!-- Modal jangen tambah sesi -->
      <div class="modal fade" id="modal-download-siswa" tabindex="-1" role="dialog" aria-labelledby="tambah-data-guru" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times-circle"></i></button>
              <h4 class="modal-title" id="myModalLabel">OPTIONS</h4>
            </div>
            <div class="modal-body">
              <form action="print.php" target="__blank" method="get">
                <div class="form-group">
                <label for="">Jenis Laporan</label>
                <select onchange="typeprint(this)" class="form-control" name="print" id="">
                  <option value="print_sesi">Data Sesi</option>
                  <option value="data_siswa">Data Siswa</option>
                  <option value="data_guru">Data Guru</option>
                  <option value="data_perolehan_suara">Perolehan Suara</option>
                </select>
                </div>
                <div class="form-group data-kelas">
                
                </div>
                <div  class="form-group">
                  <label for="">Simpan File</label>
                  <select class="form-control" required name="with_download" id="">
                    <option value="false">Jangan baca saja</option>
                    <option value="true">Download file pdf</option>
                  </select>
              </div>
                <button  type="submit" class="btn btn-success">Download <i class="fa fa-download"></i></button>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- ./end modal tambah data -->
      </div>
    </div>
  </div>
</div>
<script>
//jangen nyokot kelas
function typeprint(e){
  if(e.value == "data_siswa"){
    var xhr = new XMLHttpRequest();
    fetch("../api/get.php?data=data_kelas",{
      method:"GET"
    }).then(response=>response.text()).then(data=>{
      document.querySelector(".data-kelas").innerHTML = data;
    });
    
  }else{
    document.querySelector(".data-kelas").innerHTML = "";
  }
}





</script>