<div class="row">
	<div class="col-lg-12">
		<div class="page-header">
			<a href="?module=beranda"><i class="fa fa-home"></i> beranda</a>&nbsp;=>&nbsp;<b><i class="fa fa-gear"></i> Setting</b>

		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<div class="row">
	<!-- panel pengaturan website -->
	<div class="container-fluid">
	<div class="row">
	<div class="col-md-5">
		<div class="panel panel-default">
			<div class="panel-heading">
				<b>JADWAL PEMILIHAN</b>
			</div>
			<div class="panel-body">
				<form method="post" action="">
				<div class="form-group">
				<?php
				if(isset($_POST['setjadwal'])){
					$dari = $_POST['dari'];
					$sampai = $_POST['sampai'];
					if($konek->query("UPDATE tb_jadwal set dari='$dari',sampai='$sampai'")){
						echo "<script>alert('Jadwal berhasil di ubah');window.location.href='?module=setting'</script>";
					}
				}
					if($get = $konek->query("SELECT * FROM tb_jadwal")){
						$gg = $get->fetch_assoc();
						$dari = $gg['dari'];
						$sampai = $gg['sampai'];
					}
					?>
				<label for="dari">Dari tanggal</label>
				<input type="date" name="dari" value="<?= isset($dari) ? $dari : "" ?>" class="form-control">
				</div>
				<div class="form-group">
			
				<label for="dari">Sampai tanggal</label>
					<input name="sampai" type="date" value="<?= isset($sampai) ? $sampai : "" ?>" class="form-control">
				</div>
				<div class="form-group">
					<button name="setjadwal" class="btn btn-primary">SET JADWAL</button>
				</div>
				</form>
		</div>
			</div>		
	</div>
<!-- reset -->
	<!-- <div class="col-md-7">
					<div class="panel panel-default">
						<div class="panel-heading">
							<b>ADVANCED</b>
						</div>
						<div class="panel-body">
							<form action="">
							<div class="form-group">
							<label for="dari">Dari tanggal</label>
								<input type="date" class="form-control">
							</div>
							<div class="form-group">
							<label for="dari">Sampai tanggal</label>
								<input type="date" class="form-control">
							</div>
							<div class="form-group">
								<button class="btn btn-primary">SET</button>
							</div>
							</form>
						</div>
					</div>
				</div>		
		</div> -->
</div>

