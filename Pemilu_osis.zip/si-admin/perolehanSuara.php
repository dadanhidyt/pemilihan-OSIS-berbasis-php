<?php
/**
 * FUngsi jangen nyein chart hasil pemilihan
 * Library nu di gunaken nyaeta moris data
 */
function Moris_Data($jenischrt = 'bar'){
  global $konek;
  //cek hela keadilan
  $_totalSuara = $konek->query("SELECT * FROM tb_suara")->num_rows;
  $_calon = $konek->query("SELECT * from tb_calon");
  if($_calon->num_rows > 0){
    while($e = $_calon->fetch_assoc()){
      $data[] = array(
        "calon:".$e['no_calon'],
        'nama'=>$e['Nama_calon'],
        'jumlah_suara'=>($konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$e['no_calon']."'")->num_rows > 0) ? $konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$e['no_calon']."'")->num_rows : 0,
        'persen'=>($konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$e['no_calon']."'")->num_rows>0) ? round($konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$e['no_calon']."'")->num_rows*100/$_totalSuara,2) : 0,
        
      );
    }
    foreach($data as $hasil){
      if($jenischrt == 'bar'){
        echo "{
          y: '".$hasil['nama']."',
          a: '".$hasil['jumlah_suara']."',
        },";
      }elseif($jenischrt == "donut"){
        echo " {
          label: '".$hasil['nama']."',
          value: ".$hasil['persen'].",
        },";
      }
    }
  }else{
    if($jenischrt == "bar"){
      echo "{
        y: 'Null',
        a: '0',
      },{
        y: 'Null2',
        a: '0',
      }";
    }elseif($jenischrt == "donut"){
      echo " {
        label: 'Jhon Doe',
        value: 0,
      },";
    }
  }
  

}
/**
 * Jangen ngaupdate hasil pemilihan
 */
function updatePerolehanSuara(){
  global $konek;
  if( $gk = $konek->query("SELECT * FROM tb_calon") ) {
    if($gk->num_rows > 0) {
      while($r = $gk->fetch_assoc()){
        $konek->query("UPDATE tb_calon SET jumlah_suara='".$konek->query("SELECT * FROM tb_suara WHERE ke_calon='".$r['no_calon']."'")->num_rows."' WHERE no_calon='".$r['no_calon']."'");
      }
    }
  }
}