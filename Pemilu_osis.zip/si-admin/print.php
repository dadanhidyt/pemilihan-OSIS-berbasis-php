<?php
session_start();
if(!isset($_SESSION['admin_login']) && $_SESSION['admin_login'] == false){
  header('location:login.php');
}
/**
 * ***************************************
 * File jangen print atawa downlod laporan
 * @author dadan hidayat
 * ***************************************
 */
//Manggil Library FPDF
include('vendor/fpdf182/fpdf.php');
//kelas jangen naggenereate pdf
class PKO_PDF extends FPDF{
  //pdf header
  function pdf_header($title,$logo = "",$title2 = ""){
    //font nya arial bold dan size nya 15 px
    $this->setFont("Arial",'B','18');
    $this->Cell(80);
    $this->Image($logo,30,10,18,18);
    $this->Cell(30,10,$title,0,0,'C');
    $this->Ln();
    $this->setFont("Arial",'','8');
    $this->Cell(190,8,$title2.' '.date("Y").'/'.date("Y",strtotime("+1 year")),0,0,'C');
    $this->Line(1000,32,0,32);
  }
  //eusi pdf jangen laporan data siswa
  function pdf_body_siswa($kelas = "all"){  
    //biasa manggil file koneksi
    include("../koneksi.php");
    $this->setFont("Times",'I','8');
    $this->Ln();
    if($kelas === 'all'){
      $this->Text(10,40,"Total Siswa: ".mysqli_num_rows($konek->query("SELECT * FROM tb_siswa")));
      $this->Text(10,45,"Sudah Memilih: ".mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE  sudah_memilih='Y'")));
      $this->Text(10,50,"Belum Memilih: ".mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE  sudah_memilih='N'")));  

    }else{
      $this->Text(10,40,"Total Siswa: ".mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE kelas_siswa='$kelas'" )));
      $this->Text(10,45,"Sudah Memilih: ".mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE kelas_siswa='$kelas' AND  sudah_memilih='Y'")));
      $this->Text(10,50,"Belum Memilih: ".mysqli_num_rows($konek->query("SELECT * FROM tb_siswa WHERE kelas_siswa='$kelas' AND  sudah_memilih='N'")));  
    }
    $this->setFont("Times",'','9');
    $this->Ln(26);
    $this->cell(10,9,"Id",1,0,"C");
    $this->cell(50,9,"Nama",1,0,"C");
    $this->cell(28,9,"Kelas",1,0,"C");
    $this->cell(28,9,"Nis",1,0,"C");
    $this->cell(15,9,"Sesi",1,0,"C");
    $this->cell(30,9,"Password",1,0,"C");
    $this->cell(30,9,"Status",1,0,"C");

    $this->Ln();
    //cek hela request dana na kabeh siswa atawa ngan sakelas
    if($kelas == 'all'){
      $q= $konek->query("SELECT * FROM tb_siswa");
    }else{
      $q = $q= $konek->query("SELECT * FROM tb_siswa WHERE kelas_siswa='$kelas'");
    }
    if($q){
      //cek hela datana aya eweh
      //mun eweh cetak tidak ada data
      if($q->num_rows ==0){
        $this->Text(100,85,"Tidak ada data");
      }else{
        $no = 0;
        //mun aya,,, Apal lahhh
        while($e = $q->fetch_object()){
          $no ++;
          $this->cell(10,9,$no,1,0,"C");
          $this->cell(50,9,$e->nama_siswa,1,0,"C");
          $this->cell(28,9,$e->kelas_siswa,1,0,"C");
          $this->cell(28,9,$e->nis_siswa,1,0,"C");
          $this->cell(15,9,$e->sesi,1,0,"C");
          $this->cell(30,9,$e->password,1,0,"C");
          if($e->sudah_memilih == "Y"){
            $this->cell(30,9,'Sudah memilih',1,0,"C");
          }else{
            $this->cell(30,9,'Belum memilih',1,0,"C");
          }
          $this->Ln();
        }
      }
    }
  }
   //fungsi jangen laporan pdf data guru
  function pdf_body_guru(){
   include("../koneksi.php");
   $this->setFont("Arial",'','8');
   $this->Ln();
   $this->Text(10,40,"Jumlah Guru: ".mysqli_num_rows($konek->query("SELECT * FROM tb_guru")));
   $this->Text(10,45,"Sudah Memilih: ".mysqli_num_rows($konek->query("SELECT * FROM tb_guru WHERE  sudah_memilih='Y'")));
   $this->Text(10,50,"Belum Memilih: ".mysqli_num_rows($konek->query("SELECT * FROM tb_guru WHERE  sudah_memilih='N'")));  
   $this->Ln(30);
   $this->Cell(18,10,"ID",1,0,"C");
   $this->Cell(80,10,"NAMA",1,0,"C");
   $this->Cell(40,10,"PASSWORD",1,0,"C");
   $this->Cell(40,10,"SUDAH MEMILIH",1,0,"C");
   $this->Ln();
   if($gg = $konek->query("SELECT * FROM tb_guru")){
    $no = 0;
    while($ggs = $gg->fetch_assoc()){
      $no++;
      $this->Cell(18,10,$no,1,0,"C");
      $this->Cell(80,10,$ggs['nama'],1,0,"C");
      $this->Cell(40,10,$ggs['password'],1,0,"C");
      $this->Cell(40,10,$ggs['sudah_memilih'] == "Y"?"YA":"TIDAK",1,0,"C");
      $this->Ln();
    }
  }
}
  //print sesi
function pdf_body_sesi(){
  include("../koneksi.php");
  $this->Ln(30);
  $this->Cell(18,10,"Sesi",1,0,"C");
  $this->Cell(65,10,"Dari Jam",1,0,"C");
  $this->Cell(65,10,"Sampai Jam",1,0,"C");
  $this->Cell(40,10,"Hari",1,0,"C");
  $this->Ln();
  if($gg = $konek->query("SELECT * FROM tb_sesi")){
    while($ggs = $gg->fetch_assoc()){
      $this->Cell(18,10,"Sesi ".$ggs['nama_sesi'],1,0,"C");
      $this->Cell(65,10,$ggs['mulai'],1,0,"C");
      $this->Cell(65,10,$ggs['akhir'],1,0,"C");
      $this->Cell(40,10,$ggs['hari'],1,0,"C");
      $this->Ln();
    }
  }


}
function Nomer_Halaman()
{
  $this->SetY(3);
  $this->SetFont('Arial','I',5);
  $this->Cell(0,1,'Hal '.$this->PageNo().'/{nb}',0,0,'L');
}
}
//lamun aya parameter url print for
//mn eweh wahhh bahaya jadi di alihken ka halaman asal
if(isset($_GET['print'])){
  //jangen laporan siswa
  if($_GET['print'] == "data_siswa"){
    //cek hela file na rek di download atawa moal
    $download = isset($_GET['with_download'])  ? $_GET['with_download'] : 'false';
    $pdf_siswa = new PKO_PDF();
    $pdf_siswa->AliasNbPages();
    $pdf_siswa->AddPage();
    $pdf_siswa->pdf_header("LAPORAN DATA SISWA",'assets/logo.jpg','Laporan siswa pemilihan smk sukajajan');
    if(isset($_GET['kelas'])){
      $kelas = $_GET['kelas'];
    }else{
      $kelas = 'all';
    }
    $pdf_siswa->pdf_body_siswa($kelas);
      //jangen nyien page 10/20
    $pdf_siswa->Nomer_Halaman();
    if(isset($_GET['kelas']) && $_GET['kelas'] !== 'all'){
      if(isset($_GET['with_download']) && $_GET['with_download']=="true"){
        $pdf_siswa->output("D",'Laporan-siswa-kelas-'.$_GET['kelas'].'.pdf');
      }else{
        $pdf_siswa->output("I",'Laporan-siswa-kelas.pdf');
      }
    }else{
      if(isset($_GET['with_download']) && $_GET['with_download']=="true"){
        $pdf_siswa->output("D",'Laporan-siswa.pdf');
      }else{
        $pdf_siswa->output("I",'Laporan-siswa.pdf');
      }
    }
      //laporan pdf jangen guru
  }elseif($_GET['print']=='print_sesi'){

    $pdf_sesi = new PKO_PDF();
    $pdf_sesi->addPage();
    $pdf_sesi->pdf_header("SESI PEMILIHAN KETUA OSIS",'assets/logo.jpg','Sesi dan hari pemilihan ketua osis');
    $pdf_sesi->pdf_body_sesi();
    if(isset($_GET['with_download']) && $_GET['with_download']=="true"){
      $pdf_sesi->output("D",'jadwal-sesi-pemilihan.pdf');
    }else{
      $pdf_sesi->output("I",'jadwal-sesi-pemilihan.pdf');
    }

  }elseif($_GET['print'] == 'data_guru'){

    $pdf_guru = new PKO_PDF();
    $pdf_guru->AddPage();
    $pdf_guru->pdf_header("LAPORAN DATA GURU",'assets/logo.jpg','Pemilihan ketua osis smk informatika sumedang');
    $pdf_guru->pdf_body_guru();
    if(isset($_GET['with_download'])){
      if($_GET['with_download'] == 'true'){
        $pdf_guru->Output("D",'Data-guru-'.rand().'.pdf');
      }else{
        $pdf_guru->Output("I",'wk.pdf');
      }
    }
  }
}else{
  header("location:index.php?module=beranda");
}
?>
