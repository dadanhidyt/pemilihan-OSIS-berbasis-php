<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Akses dilarang</title>
	<style>
		*{
			font-family:monospace;
		}
		#clientip,#date{
			color: maroon;
			font-size: 12px;
		}

	</style>
</head>
<body>
	<?php 
	include( "code/comon.function.php" );
	?>
	<h1>403</h1>
	<p>
	Oppss!! Halaman ini sangat rahasia,, Kamu tidak bisa masuk ke halaman ini <br><br>
		<samp id="clientip">Ip Kamu: <?= $_SERVER['REMOTE_ADDR'] ?></samp><br>
		<samp id="date"><?php echo TanggalIndonesia(date("Y-m-d")) ?></samp>
	</p>
</body>
</html>